THU AO - Nuoi nhieu thu ao (Android, Kotlin)
- 12 con giap: Ty (chuot), Suu (trau/bo), Dan (ho), Mao (meo), Thin (rong), Ty (ran), Ngo (ngua), Mui (de/cuu), Than (khi), Dau (ga), Tuat (cho), Hoi (heo).
- Them: meo, tho, gau/panda, cao; rong chibi; nhan vat tu anh trong may.
- Chon be nao chay tren man hinh bang nut Hien/an (toi da 8 be cung luc).
Build: Android Studio (Build > Build APK) hoac day ThuAo.zip len GitHub, tab Actions se build ra app-debug.apk.
