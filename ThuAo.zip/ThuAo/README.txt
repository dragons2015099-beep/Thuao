THU AO - Nuoi nhieu thu ao (Android, Kotlin)
- Hang tren cung: chon be, bam dau + de them be moi: meo chibi, rong chibi, hoac nhan vat tu anh trong may.
- Be tu anh: anh duoc uon luoi de co cu dong that (tho, buoc chan luan phien, nhun nay deo, bay luon uon song, nhai khi an...).
  Nut "Chinh anh & cu dong": chon kieu cu dong (di bo / nhun nay / bay luon), huong mat cua anh, muc xoa nen.
- Tren san khau trong app, be tu di tai cho de xem thu kieu cu dong.
- "Tha tat ca thu ra man hinh": cac be chay / bay muot, cham vao be de hien menu nhanh, keo roi buong tay de nem.
Build: Android Studio (Build > Build APK) hoac day ThuAo.zip len GitHub, tab Actions se build ra app-debug.apk.
