package com.example.thuao

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import java.io.File
import kotlin.math.max
import kotlin.math.min

object Looks {
    /** Tên màu, màu thân, màu bụng của mèo vẽ sẵn. */
    val CAT_COLORS = listOf(
        Triple("Cam", "#FFD9A0", "#FFF1D6"),
        Triple("Xám", "#C9CED6", "#F1F3F6"),
        Triple("Hồng", "#FFC8DD", "#FFEAF2"),
        Triple("Trắng", "#FFFFFF", "#F4F4F4"),
        Triple("Đen", "#6B6B76", "#A8A8B3"),
        Triple("Bạc hà", "#BFEBD4", "#E8F8EF")
    )

    /** Tên rồng, màu thân, màu vảy ánh. */
    val DRAGON_COLORS = listOf(
        Triple("Bạch long (trắng ngọc)", "#F2FAFA", "#9FD8D0"),
        Triple("Kim long (vàng)", "#FFF6D6", "#F0C24B"),
        Triple("Thanh long (xanh lá)", "#E3F6E8", "#58B88A"),
        Triple("Lam long (xanh dương)", "#E3EEFF", "#5B8EE6")
    )

    val BUNNY_COLORS = listOf(
        Triple("Trắng", "#FFFFFF", "#FFE6EE"),
        Triple("Nâu kem", "#E9CBA7", "#FFF3E2"),
        Triple("Xám", "#D3D6DD", "#F4F5F8"),
        Triple("Hồng", "#FFD1E1", "#FFF0F5")
    )
    val BEAR_COLORS = listOf(
        Triple("Gấu nâu", "#B9845A", "#E8CFAF"),
        Triple("Panda", "#FFFFFF", "#F6F6F6"),
        Triple("Gấu bắc cực", "#FFFDF7", "#FFFFFF")
    )
    val FOX_COLORS = listOf(
        Triple("Cáo cam", "#F29B4B", "#FFF4E5"),
        Triple("Cáo tuyết", "#EDF3F7", "#FFFFFF"),
        Triple("Cáo đỏ", "#D9663C", "#FFF0E0")
    )
    val DOG_COLORS = listOf(
        Triple("Vàng", "#E8B97A", "#FFF2DD"),
        Triple("Nâu", "#A8734A", "#F0D9BE"),
        Triple("Trắng", "#F7F7F7", "#FFFFFF"),
        Triple("Đen", "#4B4B55", "#9A9AA6")
    )
    val MOUSE_COLORS = listOf(
        Triple("Xám", "#C9CCD6", "#F4F5F8"),
        Triple("Trắng", "#FFFFFF", "#FFE8EE"),
        Triple("Nâu", "#C79A74", "#F3E2CF")
    )
    val OX_COLORS = listOf(
        Triple("Trâu nâu", "#B98B62", "#F1DFC8"),
        Triple("Trâu đen", "#55505A", "#B5AFB8"),
        Triple("Bò sữa", "#FFFFFF", "#F4F4F4")
    )
    val TIGER_COLORS = listOf(
        Triple("Hổ vàng", "#F5A93C", "#FFF1D8"),
        Triple("Hổ trắng", "#F4F1EA", "#FFFFFF")
    )
    val HORSE_COLORS = listOf(
        Triple("Ngựa nâu", "#C98F5B", "#F3E2CF"),
        Triple("Ngựa trắng", "#FFFFFF", "#F0F0F5"),
        Triple("Ngựa đen", "#4D4A55", "#A9A6B2")
    )
    val GOAT_COLORS = listOf(
        Triple("Dê trắng", "#FBFBFB", "#FFFFFF"),
        Triple("Dê nâu", "#CDA77D", "#F5E6D3"),
        Triple("Cừu bông", "#FFFFFF", "#F4F4F4")
    )
    val MONKEY_COLORS = listOf(
        Triple("Khỉ nâu", "#B07A52", "#F0D3B6"),
        Triple("Khỉ vàng", "#E3B063", "#FFE9C7"),
        Triple("Khỉ xám", "#A3A7B3", "#E8E9EE")
    )
    val PIG_COLORS = listOf(
        Triple("Heo hồng", "#FFB7C8", "#FFE1EA"),
        Triple("Heo hồng nhạt", "#FFD4DE", "#FFF0F4")
    )
    val ROOSTER_COLORS = listOf(
        Triple("Gà vàng", "#FFD54F", "#FFF2B0"),
        Triple("Gà đỏ cam", "#F2793D", "#FFE0B8"),
        Triple("Gà trắng", "#FFFFFF", "#FFF5E0")
    )
    val SNAKE_COLORS = listOf(
        Triple("Rắn xanh lá", "#8FD36B", "#F4F9C8"),
        Triple("Rắn vàng", "#F6D55C", "#FFF6CC"),
        Triple("Rắn tím", "#B79CF2", "#EBE2FF")
    )
    val SPECIES = listOf(
        "cat" to "Mèo", "bunny" to "Thỏ", "bear" to "Gấu", "fox" to "Cáo", "dog" to "Chó",
        "mouse" to "Chuột", "ox" to "Trâu / Bò", "tiger" to "Hổ", "horse" to "Ngựa",
        "goat" to "Dê / Cừu", "monkey" to "Khỉ", "pig" to "Heo", "rooster" to "Gà", "snake" to "Rắn"
    )

    /** 12 con giáp: tên can chi, tên con vật, loài trong app. */
    val ZODIAC = listOf(
        Triple("Tý", "Chuột", "mouse"), Triple("Sửu", "Trâu", "ox"), Triple("Dần", "Hổ", "tiger"),
        Triple("Mão", "Mèo", "cat"), Triple("Thìn", "Rồng", "dragon"), Triple("Tỵ", "Rắn", "snake"),
        Triple("Ngọ", "Ngựa", "horse"), Triple("Mùi", "Dê", "goat"), Triple("Thân", "Khỉ", "monkey"),
        Triple("Dậu", "Gà", "rooster"), Triple("Tuất", "Chó", "dog"), Triple("Hợi", "Heo", "pig")
    )

    fun palette(sp: String): List<Triple<String, String, String>> = when (sp) {
        "bunny" -> BUNNY_COLORS
        "bear" -> BEAR_COLORS
        "fox" -> FOX_COLORS
        "dog" -> DOG_COLORS
        "mouse" -> MOUSE_COLORS
        "ox" -> OX_COLORS
        "tiger" -> TIGER_COLORS
        "horse" -> HORSE_COLORS
        "goat" -> GOAT_COLORS
        "monkey" -> MONKEY_COLORS
        "pig" -> PIG_COLORS
        "rooster" -> ROOSTER_COLORS
        "snake" -> SNAKE_COLORS
        "dragon" -> DRAGON_COLORS
        else -> CAT_COLORS
    }

    fun lookFor(sp: String, i: Int) = when (sp) {
        "cat" -> "cat:$i"
        "dragon" -> "dragon:$i"
        else -> "an:$sp:$i"
    }

    private val cache = HashMap<String, Bitmap>()

    fun bitmap(path: String): Bitmap? {
        cache[path]?.let { return it }
        val b = BitmapFactory.decodeFile(path) ?: return null
        cache[path] = b
        return b
    }

    /** Nạp lại ảnh sau khi xử lý lại (đổi độ xóa nền). */
    fun reload(path: String) {
        cache.remove(path)
    }

    fun drop(path: String) {
        cache.remove(path)
        File(path).delete()
        File(path.removeSuffix(".png") + "_orig.png").delete()
    }
}

/** Biến một ảnh bất kỳ thành hình nhân vật: thu nhỏ, xóa nền đơn sắc (chỉnh được), làm mềm viền, cắt sát viền. */
object SpriteMaker {
    private fun dir(ctx: Context) = File(ctx.filesDir, "sprites").apply { mkdirs() }

    /** Đọc ảnh người dùng chọn, lưu bản gốc thu nhỏ rồi tạo hình nhân vật. Trả về đường dẫn ảnh nhân vật. */
    fun make(ctx: Context, uri: Uri, id: String): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 800) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val scale = min(1f, 320f / max(src.width, src.height))
            val small = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    src,
                    (src.width * scale).toInt().coerceAtLeast(1),
                    (src.height * scale).toInt().coerceAtLeast(1),
                    true
                )
            } else src
            File(dir(ctx), "${id}_orig.png").outputStream().use {
                small.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            build(ctx, id, 52)
        } catch (e: Exception) {
            null
        }
    }

    /** Làm lại hình nhân vật từ ảnh gốc. tol = 0: giữ nguyên ảnh, càng lớn càng xóa mạnh. */
    fun build(ctx: Context, id: String, tol: Int): String? {
        return try {
            val orig = BitmapFactory.decodeFile(File(dir(ctx), "${id}_orig.png").absolutePath) ?: return null
            var bmp = orig.copy(Bitmap.Config.ARGB_8888, true)
            if (tol > 0) {
                removeBackground(bmp, tol)
                // xóa nền lỡ ăn mất cả nhân vật thì dùng lại ảnh gốc
                if (opaqueCount(bmp) < bmp.width * bmp.height * 0.02) {
                    bmp = orig.copy(Bitmap.Config.ARGB_8888, true)
                }
            }
            val out = trim(bmp)
            val f = File(dir(ctx), "$id.png")
            f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun opaqueCount(b: Bitmap): Int {
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        var n = 0
        for (c in px) if (Color.alpha(c) > 20) n++
        return n
    }

    /** Xóa vùng nền liền với 4 cạnh ảnh có màu gần giống màu 4 góc, viền còn lại làm mềm. */
    private fun removeBackground(b: Bitmap, tolerance: Int) {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val corners = intArrayOf(px[0], px[w - 1], px[(h - 1) * w], px[h * w - 1])
        if (corners.all { Color.alpha(it) < 16 }) return      // ảnh đã có nền trong suốt
        var br = 0
        var bg = 0
        var bb = 0
        for (c in corners) { br += Color.red(c); bg += Color.green(c); bb += Color.blue(c) }
        br /= 4; bg /= 4; bb /= 4
        val tol2 = tolerance * tolerance
        val seen = BooleanArray(w * h)
        val queue = IntArray(w * h)
        var head = 0
        var tail = 0
        fun push(i: Int) {
            if (seen[i]) return
            val c = px[i]
            val dr = Color.red(c) - br
            val dg = Color.green(c) - bg
            val db = Color.blue(c) - bb
            if (Color.alpha(c) < 16 || dr * dr + dg * dg + db * db <= tol2) {
                seen[i] = true
                queue[tail++] = i
            }
        }
        for (x in 0 until w) { push(x); push((h - 1) * w + x) }
        for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        val out = IntArray(w * h)
        for (i in 0 until w * h) {
            if (seen[i]) {
                out[i] = 0
            } else {
                val x = i % w
                val y = i / w
                val edge = (x > 0 && seen[i - 1]) || (x < w - 1 && seen[i + 1]) ||
                    (y > 0 && seen[i - w]) || (y < h - 1 && seen[i + w])
                out[i] = if (edge) ((170 shl 24) or (px[i] and 0x00FFFFFF)) else px[i]
            }
        }
        b.setPixels(out, 0, w, 0, 0, w, h)
    }

    private fun trim(b: Bitmap): Bitmap {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) for (x in 0 until w) {
            if (Color.alpha(px[y * w + x]) > 20) {
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (maxX < 0) return b
        return Bitmap.createBitmap(b, minX, minY, maxX - minX + 1, maxY - minY + 1)
    }
}
