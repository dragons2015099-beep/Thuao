package com.example.thuao

import android.content.Context

enum class Mood { HAPPY, NORMAL, HUNGRY, SAD, TIRED, DIRTY, SLEEP }

/** Trạng thái một bé thú, lưu theo id và tự giảm theo thời gian thật (kể cả khi tắt app). */
class PetState(ctx: Context, val id: String) {
    private val p = ctx.applicationContext.getSharedPreferences("pet_$id", Context.MODE_PRIVATE)

    var name = "Mochi"
    var look = "cat:0"        // "cat:<số màu>" hoặc "img:<đường dẫn ảnh>"
    var hunger = 80f          // độ no
    var happy = 80f
    var energy = 80f
    var clean = 80f
    var xp = 0
    var sleeping = false
    var motion = "walk"       // kiểu cử động của bé từ ảnh: walk / bounce / fly
    var faceLeft = false      // ảnh gốc đang quay mặt sang trái
    private var born = System.currentTimeMillis()
    private var last = born

    val level: Int get() = 1 + xp / 40
    val ageDays: Int get() = ((System.currentTimeMillis() - born) / 86_400_000L).toInt()

    init {
        if (p.contains("last")) {
            name = p.getString("name", name) ?: name
            look = p.getString("look", look) ?: look
            motion = p.getString("motion", motion) ?: motion
            faceLeft = p.getBoolean("faceLeft", false)
            hunger = p.getFloat("hunger", hunger)
            happy = p.getFloat("happy", happy)
            energy = p.getFloat("energy", energy)
            clean = p.getFloat("clean", clean)
            xp = p.getInt("xp", 0)
            sleeping = p.getBoolean("sleeping", false)
            born = p.getLong("born", born)
            last = p.getLong("last", born)
        }
        decay()
        save()
    }

    private fun decay() {
        val now = System.currentTimeMillis()
        val h = ((now - last).coerceAtLeast(0L) / 3_600_000f).coerceAtMost(72f)
        last = now
        if (h <= 0f) return
        if (sleeping) {
            energy += 14f * h; hunger -= 2f * h; happy -= 1f * h; clean -= 1f * h
            if (energy >= 100f) sleeping = false
        } else {
            hunger -= 6f * h; happy -= 4f * h; energy -= 3f * h; clean -= 3f * h
            if (hunger < 20f) happy -= 3f * h
        }
        clamp()
    }

    private fun clamp() {
        hunger = hunger.coerceIn(0f, 100f)
        happy = happy.coerceIn(0f, 100f)
        energy = energy.coerceIn(0f, 100f)
        clean = clean.coerceIn(0f, 100f)
    }

    fun save() {
        p.edit()
            .putString("name", name).putString("look", look)
            .putString("motion", motion).putBoolean("faceLeft", faceLeft)
            .putFloat("hunger", hunger).putFloat("happy", happy)
            .putFloat("energy", energy).putFloat("clean", clean)
            .putInt("xp", xp).putBoolean("sleeping", sleeping)
            .putLong("born", born).putLong("last", last)
            .apply()
    }

    fun mood(): Mood = when {
        sleeping -> Mood.SLEEP
        hunger < 25f -> Mood.HUNGRY
        energy < 20f -> Mood.TIRED
        clean < 25f -> Mood.DIRTY
        happy < 30f -> Mood.SAD
        (hunger + happy + energy + clean) / 4f >= 65f -> Mood.HAPPY
        else -> Mood.NORMAL
    }

    fun feed(): String {
        if (sleeping) return "$name đang ngủ, đừng đánh thức bé nhé"
        if (hunger > 92f) return "$name no căng rồi, không ăn nổi nữa"
        hunger += 30f; happy += 3f; clean -= 2f; xp += 2; clamp()
        return "$name ăn ngon lành!"
    }

    fun play(): String {
        if (sleeping) return "$name đang ngủ, đừng đánh thức bé nhé"
        if (energy < 15f) return "$name mệt quá rồi, cho bé ngủ đi"
        if (hunger < 15f) return "$name đói quá, không muốn chơi"
        happy += 20f; energy -= 12f; hunger -= 6f; clean -= 3f; xp += 4; clamp()
        return "$name chơi rất vui!"
    }

    fun bath(): String {
        if (sleeping) return "$name đang ngủ, đừng đánh thức bé nhé"
        clean += 45f; happy -= 2f; xp += 2; clamp()
        return "$name sạch bong, thơm tho!"
    }

    fun toggleSleep(): String {
        sleeping = !sleeping
        return if (sleeping) "$name đi ngủ, ngủ ngon nhé…" else "$name thức dậy rồi!"
    }

    fun cuddle(): String {
        happy += 4f; xp += 1; clamp()
        return "$name thích được vuốt ve!"
    }
}
