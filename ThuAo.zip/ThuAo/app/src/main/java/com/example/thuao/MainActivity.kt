package com.example.thuao

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var pet: PetView
    private lateinit var titleView: TextView
    private lateinit var msg: TextView
    private lateinit var sleepBtn: Button
    private lateinit var overlayBtn: Button
    private lateinit var selector: LinearLayout
    private val bars = ArrayList<ProgressBar>()
    private var currentId = ""

    private var tickN = 0
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            tickN++
            main.postDelayed(this, 1500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor("#33281F"))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun statRow(parent: LinearLayout, label: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        row.addView(tv(label, 14f), LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        bars.add(bar)
        row.addView(bar, LinearLayout.LayoutParams(0, dp(14), 1f))
        parent.addView(row)
    }

    private fun actionBtn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PetStore.ensureDefault(this)
        currentId = PetStore.selected(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(30), dp(16), dp(24))
        }

        col.addView(tv("Thú Ảo của bạn", 20f, true).apply { gravity = Gravity.CENTER })
        selector = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(
            HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(selector)
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
        )

        titleView = tv("", 18f, true).apply { gravity = Gravity.CENTER }
        col.addView(titleView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) })

        pet = PetView(this)
        val stage = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FFF7E8"))
                cornerRadius = dp(18).toFloat()
            }
        }
        stage.addView(pet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240)))
        pet.setOnClickListener {
            pet.hearts()
            act { it.cuddle() }
        }
        // bé nhìn theo ngón tay khi bạn rê trên sân khấu, nhấc tay là vuốt ve
        pet.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
                    pet.gazeTo((e.x / v.width.coerceAtLeast(1)) * 2f - 1f)
                MotionEvent.ACTION_UP -> {
                    pet.gazeTo(0f)
                    v.performClick()
                }
                MotionEvent.ACTION_CANCEL -> pet.gazeTo(0f)
            }
            true
        }
        col.addView(
            stage,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
        )

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(4))
        }
        statRow(stats, "🍖 Độ no")
        statRow(stats, "😊 Vui vẻ")
        statRow(stats, "⚡ Năng lượng")
        statRow(stats, "🛁 Sạch sẽ")
        col.addView(stats)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sleepBtn = actionBtn("😴 Ngủ") { pet.hop(); act { it.toggleSleep() } }
        listOf(
            actionBtn("🍖 Cho ăn") { anim(Act.EAT); act { it.feed() } },
            actionBtn("🎾 Chơi") { anim(Act.PLAY); act { it.play() } },
            actionBtn("🛁 Tắm") { anim(Act.BATH); act { it.bath() } },
            sleepBtn
        ).forEach { buttons.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        col.addView(buttons)

        msg = tv("Chạm vào bé để vuốt ve nhé!", 14f).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        col.addView(msg)

        overlayBtn = Button(this).apply {
            isAllCaps = false
            setOnClickListener { toggleOverlay() }
        }
        col.addView(overlayBtn)
        col.addView(Button(this).apply {
            text = "Đổi tên bé này"
            isAllCaps = false
            setOnClickListener { rename() }
        })
        col.addView(Button(this).apply {
            text = "Chỉnh ảnh & cử động"
            isAllCaps = false
            setOnClickListener { editLook() }
        })
        col.addView(Button(this).apply {
            text = "Xóa bé này"
            isAllCaps = false
            setOnClickListener { deleteCurrent() }
        })
        col.addView(
            tv(
                "Bấm dấu ＋ ở hàng trên để thêm bé mới: mèo chibi nhiều màu, hoặc nhân vật từ ảnh trong máy " +
                    "(ảnh PNG nền trong suốt hoặc nền đơn sắc là đẹp nhất). " +
                    "Bấm \"Thả tất cả thú ra màn hình\" để các bé cùng chạy nhảy trên mọi ứng dụng. " +
                    "Các chỉ số tụt dần theo thời gian thật, nhớ cho các bé ăn và đi ngủ.",
                13f
            ).apply { setPadding(0, dp(14), 0, 0) }
        )
        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        applyLook()
        buildSelector()
    }

    override fun onResume() {
        super.onResume()
        main.post(tick)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(tick)
    }

    // ---------- hàng chọn bé ----------
    private fun thumb(look: String): Bitmap {
        val s = dp(56)
        val v = PetView(this)
        v.setLook(this, look)
        v.measure(
            View.MeasureSpec.makeMeasureSpec(s, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(s, View.MeasureSpec.EXACTLY)
        )
        v.layout(0, 0, s, s)
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        v.draw(Canvas(b))
        return b
    }

    private fun buildSelector() {
        selector.removeAllViews()
        for (id in PetStore.ids(this)) {
            val s = PetState(this, id)
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(if (id == currentId) Color.parseColor("#FFE2B8") else Color.TRANSPARENT)
                }
                setOnClickListener { select(id) }
            }
            item.addView(
                ImageView(this).apply { setImageBitmap(thumb(s.look)) },
                LinearLayout.LayoutParams(dp(56), dp(56))
            )
            item.addView(
                tv(s.name, 12f).apply { gravity = Gravity.CENTER; maxLines = 1 },
                LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            selector.addView(item)
        }
        val add = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setOnClickListener { addDialog() }
        }
        add.addView(
            tv("＋", 30f, true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(dp(56), dp(56))
        )
        add.addView(tv("Thêm", 12f).apply { gravity = Gravity.CENTER })
        selector.addView(add)
    }

    private fun applyLook() {
        val s = PetState(this, currentId)
        pet.setLook(this, s.look)
        pet.setStyle(s.motion, s.faceLeft)
    }

    private fun select(id: String) {
        currentId = id
        PetStore.select(this, id)
        applyLook()
        buildSelector()
        refresh()
    }

    // ---------- thêm / xóa / đổi tên ----------
    private fun askName(default: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { setText(default) }
        AlertDialog.Builder(this)
            .setTitle("Đặt tên cho bé")
            .setView(et)
            .setPositiveButton("Lưu") { _, _ ->
                val n = et.text.toString().trim()
                onOk(if (n.isEmpty()) default else n)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun addDialog() {
        if (PetStore.ids(this).size >= 12) {
            toast("Tối đa 12 bé thôi nhé")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Thêm bé mới")
            .setItems(
                arrayOf("🐱 Mèo chibi (chọn màu)", "🐉 Rồng chibi (chọn loại)", "🖼 Nhân vật từ ảnh trong máy")
            ) { _, which ->
                when (which) {
                    0 -> pickCatColor()
                    1 -> pickDragonColor()
                    else -> pickImage()
                }
            }
            .show()
    }

    private fun pickCatColor() {
        AlertDialog.Builder(this)
            .setTitle("Chọn màu lông")
            .setItems(Looks.CAT_COLORS.map { it.first }.toTypedArray()) { _, idx ->
                askName("Bé mới") { name ->
                    val id = PetStore.add(this, name, "cat:$idx")
                    select(id)
                }
            }
            .show()
    }

    private fun pickDragonColor() {
        AlertDialog.Builder(this)
            .setTitle("Chọn loại rồng")
            .setItems(Looks.DRAGON_COLORS.map { it.first }.toTypedArray()) { _, idx ->
                askName("Rồng nhỏ") { name ->
                    val id = PetStore.add(this, name, "dragon:$idx")
                    select(id)
                }
            }
            .show()
    }

    private fun pickImage() {
        @Suppress("DEPRECATION")
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 200)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 200 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val id = "p" + System.currentTimeMillis()
        val path = SpriteMaker.make(this, uri, id)
        if (path == null) {
            toast("Không đọc được ảnh này, thử ảnh khác nhé")
            return
        }
        askName("Bé mới") { name ->
            PetStore.add(this, name, "img:$path", id)
            select(id)
            toast("Đã thêm! Nếu chưa đẹp, bấm \"Chỉnh ảnh & cử động\"")
        }
    }

    // ---------- chỉnh bé từ ảnh ----------
    private fun editLook() {
        val s = PetState(this, currentId)
        if (!s.look.startsWith("img:")) {
            toast("Chỉ chỉnh được bé tạo từ ảnh")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Chỉnh ${s.name}")
            .setItems(arrayOf("🏃 Kiểu cử động", "↔ Ảnh đang quay mặt sang hướng nào", "✂ Xóa nền")) { _, which ->
                when (which) {
                    0 -> pickMotion()
                    1 -> pickFacing()
                    else -> pickBackground()
                }
            }
            .show()
    }

    private fun pickMotion() {
        val values = listOf("walk", "bounce", "fly")
        AlertDialog.Builder(this)
            .setTitle("Kiểu cử động")
            .setItems(
                arrayOf(
                    "Đi bộ (nhân vật đứng bằng hai chân)",
                    "Nhún nảy (thú tròn, slime)",
                    "Bay lượn (rồng, chim, ma, thần tiên)"
                )
            ) { _, which ->
                act { s -> s.motion = values[which]; "Đã đổi kiểu cử động!" }
                applyLook()
            }
            .show()
    }

    private fun pickFacing() {
        AlertDialog.Builder(this)
            .setTitle("Trong ảnh, nhân vật nhìn sang…")
            .setItems(arrayOf("Bên phải", "Bên trái", "Nhìn thẳng")) { _, which ->
                act { s -> s.faceLeft = (which == 1); "Đã chỉnh hướng ảnh!" }
                applyLook()
            }
            .show()
    }

    private fun pickBackground() {
        val tols = intArrayOf(0, 30, 52, 80)
        AlertDialog.Builder(this)
            .setTitle("Xóa nền")
            .setItems(
                arrayOf(
                    "Không xóa (ảnh đã tách nền sẵn)",
                    "Xóa nhẹ (nền gần trắng, sạch)",
                    "Xóa vừa (mặc định)",
                    "Xóa mạnh (nền loang, nhiều sắc độ)"
                )
            ) { _, which ->
                val look = PetState(this, currentId).look
                val path = look.removePrefix("img:")
                val id = java.io.File(path).nameWithoutExtension
                val out = SpriteMaker.build(this, id, tols[which])
                if (out == null) {
                    toast("Không xử lý lại được ảnh này")
                } else {
                    Looks.reload(out)
                    applyLook()
                    buildSelector()
                    toast("Đã xóa nền lại. Thả bé ra màn hình lần nữa để thấy thay đổi")
                }
            }
            .show()
    }

    private fun rename() {
        askName(PetState(this, currentId).name) { n ->
            act { s -> s.name = n; "Đã đổi tên!" }
            buildSelector()
        }
    }

    private fun deleteCurrent() {
        if (PetStore.ids(this).size <= 1) {
            toast("Cần giữ lại ít nhất một bé")
            return
        }
        val name = PetState(this, currentId).name
        AlertDialog.Builder(this)
            .setTitle("Xóa $name?")
            .setMessage("Bé sẽ biến mất vĩnh viễn, không khôi phục được.")
            .setPositiveButton("Xóa") { _, _ ->
                PetStore.remove(this, currentId)
                currentId = PetStore.ids(this).first()
                PetStore.select(this, currentId)
                applyLook()
                buildSelector()
                refresh()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    // ---------- chơi với bé ----------
    /** Chỉ phát hoạt hình ăn/chơi/tắm khi bé đang thức. */
    private fun anim(a: Act) {
        if (!PetState(this, currentId).sleeping) pet.doAct(a)
    }

    private fun act(f: (PetState) -> String) {
        val s = PetState(this, currentId)
        val m = f(s)
        s.save()
        msg.text = m
        refresh()
    }

    private fun refresh() {
        val s = PetState(this, currentId)
        titleView.text = "${s.name} · Cấp ${s.level} · ${s.ageDays} ngày tuổi"
        bars[0].progress = s.hunger.toInt()
        bars[1].progress = s.happy.toInt()
        bars[2].progress = s.energy.toInt()
        bars[3].progress = s.clean.toInt()
        pet.mood = s.mood()
        // trên sân khấu, bé cứ vài giây lại đi tại chỗ một lúc để bạn xem thử kiểu cử động
        pet.walking = s.mood() != Mood.SLEEP && (tickN % 4) >= 2
        pet.facing = if ((tickN / 4) % 2 == 0) 1 else -1
        sleepBtn.text = if (s.sleeping) "☀️ Dậy" else "😴 Ngủ"
        overlayBtn.text = if (PetStore.isOverlayOn(this)) "Thu các bé về" else "Thả tất cả thú ra màn hình"
    }

    private fun toggleOverlay() {
        if (PetStore.isOverlayOn(this)) {
            stopService(Intent(this, PetOverlayService::class.java))
            PetStore.setOverlayOn(this, false)
            refresh()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(
                this,
                "Bật quyền \"Hiển thị trên các ứng dụng khác\" rồi quay lại bấm lại nút này",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        startForegroundService(Intent(this, PetOverlayService::class.java))
        moveTaskToBack(true)
    }
}
