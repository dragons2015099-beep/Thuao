package com.example.thuao

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Hành động có hoạt hình riêng khi bấm Cho ăn / Chơi / Tắm. */
enum class Act { NONE, EAT, PLAY, BATH }

/**
 * Vẽ một bé thú: mèo chibi, rồng chibi (vẽ bằng mã), hoặc ảnh nhân vật do bạn thêm.
 * Mọi bé đều có hiệu ứng ăn, chơi bóng, tắm bong bóng, ngủ, nhả tim.
 */
class PetView(ctx: Context) : View(ctx) {
    var mood = Mood.NORMAL
    var walking = false
    var facing = 1

    private var sprite: Bitmap? = null
    private var isDragon = false
    private var hopStart = -100000L
    private var heartStart = -100000L
    private var spinStart = -100000L
    private var act = Act.NONE
    private var actStart = -100000L
    private var faceScale = 1f        // xoay người mượt khi đổi hướng
    private var squashAmt = 0f        // >0 bóp xuống khi tiếp đất, <0 giãn ra khi bật nhảy
    private var gaze = 0f
    private var gazeCur = 0f
    private var motion = "walk"
    private var faceLeft = false
    private val MESH_W = 8
    private val MESH_H = 14
    private val mesh = FloatArray((8 + 1) * (14 + 1) * 2)

    private var body = Color.parseColor("#FFD9A0")
    private var belly = Color.parseColor("#FFF1D6")
    private var dragonBody = Color.parseColor("#F2FAFA")
    private var dragonAccent = Color.parseColor("#9FD8D0")
    private val pink = Color.parseColor("#FFB3B8")
    private val ink = Color.parseColor("#4A3326")
    private val ink2 = Color.parseColor("#5E7C85")

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = ink
        strokeWidth = 1.6f
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val spritePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val grayFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0.35f) })
    private val path = Path()
    private val rf = RectF()
    private val dst = RectF()
    private val pi = Math.PI.toFloat()

    fun setLook(ctx: Context, look: String) {
        sprite = null
        isDragon = false
        when {
            look.startsWith("img:") -> sprite = Looks.bitmap(look.removePrefix("img:"))
            look.startsWith("dragon:") -> {
                isDragon = true
                val i = (look.removePrefix("dragon:").toIntOrNull() ?: 0).coerceIn(0, Looks.DRAGON_COLORS.size - 1)
                dragonBody = Color.parseColor(Looks.DRAGON_COLORS[i].second)
                dragonAccent = Color.parseColor(Looks.DRAGON_COLORS[i].third)
            }
            else -> {
                val i = (look.removePrefix("cat:").toIntOrNull() ?: 0).coerceIn(0, Looks.CAT_COLORS.size - 1)
                body = Color.parseColor(Looks.CAT_COLORS[i].second)
                belly = Color.parseColor(Looks.CAT_COLORS[i].third)
            }
        }
        invalidate()
    }

    /** Kiểu cử động ("walk" / "bounce" / "fly") và ảnh gốc có đang quay mặt sang trái không. */
    fun setStyle(m: String, left: Boolean) {
        motion = m
        faceLeft = left
    }

    fun hop() { hopStart = SystemClock.uptimeMillis() }

    fun hearts() {
        heartStart = SystemClock.uptimeMillis()
        if (isDragon) spinStart = heartStart
        hop()
    }

    fun doAct(a: Act) {
        act = a
        actStart = SystemClock.uptimeMillis()
    }

    /** Tiếp đất: bóp người xuống rồi bật lại. */
    fun landed(strength: Float) { squashAmt = strength.coerceIn(0f, 0.25f) }

    /** Bật nhảy: giãn người ra. */
    fun jumped() { squashAmt = -0.12f }

    /** Nhìn theo ngón tay: -1 (trái) đến 1 (phải), 0 là nhìn thẳng. */
    fun gazeTo(x: Float) { gaze = x.coerceIn(-1f, 1f) }

    private fun actTime(now: Long): Long {
        val t = now - actStart
        return if (act != Act.NONE && t in 0..2600) t else -1L
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = SystemClock.uptimeMillis()
        faceScale += (facing - faceScale) * 0.28f
        squashAmt *= 0.86f
        gazeCur += (gaze - gazeCur) * 0.2f
        val u = min(width, height) / 100f
        if (u > 0f) {
            c.save()
            c.translate((width - 100f * u) / 2f, height - 100f * u)
            c.scale(u, u)
            drawPet(c, now)
            c.restore()
        }
        postInvalidateOnAnimation()
    }

    private fun lerp(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    private fun bez(t: Float, a: Float, b: Float, c: Float, d: Float): Float {
        val u = 1f - t
        return u * u * u * a + 3f * u * u * t * b + 3f * u * t * t * c + t * t * t * d
    }

    private fun oval(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, outline: Boolean = true) {
        rf.set(l, t, r, b)
        fill.color = color
        c.drawOval(rf, fill)
        if (outline) c.drawOval(rf, ln)
    }

    private fun ear(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        path.reset()
        path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
        fill.color = body
        c.drawPath(path, fill)
        c.drawPath(path, ln)
        val mx = (x1 + x2 + x3) / 3f
        val my = (y1 + y2 + y3) / 3f
        path.reset()
        path.moveTo(mx + (x1 - mx) * 0.55f, my + (y1 - my) * 0.55f)
        path.lineTo(mx + (x2 - mx) * 0.55f, my + (y2 - my) * 0.55f)
        path.lineTo(mx + (x3 - mx) * 0.55f, my + (y3 - my) * 0.55f)
        path.close()
        fill.color = pink
        c.drawPath(path, fill)
    }

    private fun eye(c: Canvas, x: Float, y: Float, blink: Boolean) {
        when {
            mood == Mood.SLEEP || blink -> {
                rf.set(x - 5f, y - 3f, x + 5f, y + 5f)
                c.drawArc(rf, 0f, 180f, false, ln)
            }
            mood == Mood.HAPPY -> {
                rf.set(x - 5f, y - 2f, x + 5f, y + 8f)
                c.drawArc(rf, 180f, 180f, false, ln)
            }
            mood == Mood.TIRED -> {
                rf.set(x - 4f, y - 1f, x + 4f, y + 3f)
                fill.color = ink
                c.drawOval(rf, fill)
            }
            else -> {
                rf.set(x - 3.6f + gazeCur * 1.8f, y - 5.5f, x + 3.6f + gazeCur * 1.8f, y + 5.5f)
                fill.color = ink
                c.drawOval(rf, fill)
                fill.color = Color.WHITE
                c.drawCircle(x + 1.2f + gazeCur * 1.8f, y - 2.4f, 1.5f, fill)
            }
        }
    }

    private fun mouth(c: Canvas, now: Long) {
        if (actTime(now) >= 0L && act == Act.EAT) {
            val chew = (sin(now * 0.03f) + 1f) / 2f
            rf.set(45f, 49f, 55f, 51f + chew * 8f)
            fill.color = Color.parseColor("#7A3B3B")
            c.drawOval(rf, fill)
            return
        }
        when (mood) {
            Mood.HAPPY -> {
                rf.set(43f, 47f, 57f, 60f)
                fill.color = Color.parseColor("#E86A7A")
                c.drawArc(rf, 0f, 180f, true, fill)
                c.drawArc(rf, 0f, 180f, true, ln)
            }
            Mood.HUNGRY -> {
                rf.set(46f, 49f, 54f, 58f)
                fill.color = Color.parseColor("#7A3B3B")
                c.drawOval(rf, fill)
            }
            Mood.SAD -> {
                rf.set(44f, 53f, 56f, 61f)
                c.drawArc(rf, 180f, 180f, false, ln)
            }
            Mood.TIRED, Mood.DIRTY -> c.drawLine(46f, 52f, 54f, 52f, ln)
            else -> {
                rf.set(44f, 48f, 50f, 54f); c.drawArc(rf, 0f, 180f, false, ln)
                rf.set(50f, 48f, 56f, 54f); c.drawArc(rf, 0f, 180f, false, ln)
            }
        }
    }

    private fun bubble(c: Canvas, s: String, x: Float, y: Float, size: Float) {
        txt.color = Color.BLACK
        txt.alpha = 255
        txt.textSize = size
        c.drawText(s, x, y, txt)
    }

    private fun drawPet(c: Canvas, now: Long) {
        val sleeping = mood == Mood.SLEEP
        val at = actTime(now)

        // bóng dưới chân (rồng thì bay trên mây)
        if (isDragon) {
            val dx = sin(now * 0.002f) * 2f
            fill.color = Color.argb(205, 255, 255, 255)
            c.drawCircle(28f + dx, 93f, 7f, fill)
            c.drawCircle(40f + dx, 95f, 9f, fill)
            c.drawCircle(54f + dx, 94f, 8.5f, fill)
            c.drawCircle(67f + dx, 93f, 7f, fill)
        } else {
            fill.color = Color.argb(50, 0, 0, 0)
            rf.set(26f, 92f, 74f, 99f)
            c.drawOval(rf, fill)
        }

        val dt = now - hopStart
        var hopY = if (dt in 0..520) -abs(sin(dt / 520f * pi)) * 20f else 0f
        if (at >= 0L && act == Act.PLAY) hopY = min(hopY, -abs(sin(at * 0.009f)) * 10f)
        val bob = when {
            sleeping -> sin(now * 0.002f) * 1.2f
            isDragon -> sin(now * 0.004f) * 3f
            walking -> abs(sin(now * 0.016f)) * -3f
            else -> sin(now * 0.004f) * 1f
        }

        val sp = sprite
        c.save()
        c.scale(1f + squashAmt, 1f - squashAmt, 50f, 96f)
        when {
            isDragon -> {
                val st = now - spinStart
                c.save()
                if (st in 0..800) c.rotate(st / 800f * 360f, 50f, 55f)
                drawDragon(c, now, hopY + bob, at)
                c.restore()
            }
            sp != null -> drawSprite(c, now, sp, hopY + bob, sleeping)
            else -> drawCat(c, now, hopY + bob)
        }
        c.restore()

        drawEffects(c, now, at)

        // bẩn
        if (mood == Mood.DIRTY) {
            fill.color = Color.parseColor("#8B6B4A")
            c.drawCircle(38f, 56f, 2.2f, fill)
            c.drawCircle(62f, 66f, 2.6f, fill)
            c.drawCircle(47f, 82f, 2.2f, fill)
            c.drawCircle(58f, 40f, 1.8f, fill)
        }

        // biểu tượng nhu cầu
        when (mood) {
            Mood.HUNGRY -> bubble(c, "🍖", 88f, 12f, 15f)
            Mood.SAD -> bubble(c, "💧", 88f, 12f, 14f)
            Mood.TIRED -> bubble(c, "💤", 88f, 12f, 14f)
            Mood.DIRTY -> bubble(c, "🧼", 88f, 12f, 14f)
            else -> {}
        }
        if (sleeping) {
            for (i in 0..2) {
                val p = ((now / 900f) + i * 0.7f) % 2.1f
                txt.color = Color.parseColor("#5B6BC0")
                txt.alpha = (255 * (1f - p / 2.1f)).toInt().coerceIn(0, 255)
                txt.textSize = 8f + i * 3f
                c.drawText("z", 76f + p * 4f, 22f - p * 9f, txt)
            }
        }

        // tim bay lên khi được vuốt ve
        val hd = now - heartStart
        if (hd in 0..1200) {
            val t = hd / 1200f
            for (i in 0..2) {
                txt.color = Color.parseColor("#FF4D6D")
                txt.alpha = ((1f - t) * 255).toInt().coerceIn(0, 255)
                txt.textSize = 12f
                c.drawText("❤", 32f + i * 18f + sin(t * 6f + i) * 3f, 14f - t * 28f + i * 5f, txt)
            }
        }
    }

    /** Hiệu ứng ăn (miếng thịt bay vào miệng), chơi (quả bóng nảy), tắm (bong bóng xà phòng). */
    private fun drawEffects(c: Canvas, now: Long, at: Long) {
        if (at < 0L) return
        when (act) {
            Act.EAT -> {
                if (at < 1100L) {
                    val k = at / 1100f
                    bubble(c, "🍖", 82f - 28f * k, 18f + 28f * k, 13f)
                } else if (at < 1700L) {
                    bubble(c, "✨", 54f, 42f - (at - 1100L) / 40f, 12f)
                }
            }
            Act.PLAY -> {
                val x = 50f + sin(at * 0.006f) * 36f
                val y = 90f - abs(sin(at * 0.009f)) * 46f
                bubble(c, "⚽", x, y, 12f)
            }
            Act.BATH -> {
                for (i in 0..8) {
                    val x = 24f + i * 6f + sin(at * 0.004f + i) * 4f
                    val y = 94f - ((at * 0.03f + i * 13f) % 78f)
                    val r = 2.2f + (i % 3)
                    fill.color = Color.argb(140, 255, 255, 255)
                    c.drawCircle(x, y, r, fill)
                    ln.strokeWidth = 0.8f
                    ln.color = Color.argb(200, 120, 190, 230)
                    c.drawCircle(x, y, r, ln)
                    ln.strokeWidth = 1.6f
                    ln.color = ink
                }
            }
            else -> {}
        }
    }

    /**
     * Ảnh nhân vật: uốn lưới (mesh) để có cử động thật chứ không chỉ lật/lắc:
     * thở, nhún theo bước, chân luân phiên (kiểu "walk"), nảy dẻo (kiểu "bounce"), uốn sóng (kiểu "fly"),
     * gật gù khi ăn, rung khi đói, xệ xuống khi buồn, lắc lư khi vui.
     */
    private fun drawSprite(c: Canvas, now: Long, bmp: Bitmap, lift: Float, sleeping: Boolean) {
        val s = min(84f / bmp.width, 86f / bmp.height)
        val w = bmp.width * s
        val h = bmp.height * s
        c.save()
        c.translate(50f, 93f + lift)
        c.scale(if (faceLeft) -faceScale else faceScale, 1f)
        val rock = when {
            walking && motion == "walk" -> sin(now * 0.016f) * 2.5f
            walking -> sin(now * 0.012f) * 4f
            sleeping -> 12f
            mood == Mood.TIRED -> 5f
            else -> sin(now * 0.003f) * 1.5f
        } + gazeCur * 6f
        c.rotate(rock)
        spritePaint.alpha = if (sleeping) 190 else 255
        spritePaint.colorFilter = if (mood == Mood.SAD || mood == Mood.TIRED) grayFilter else null
        drawSpriteMesh(c, now, bmp, w, h, sleeping)
        c.restore()
    }

    private fun drawSpriteMesh(c: Canvas, now: Long, bmp: Bitmap, w: Float, h: Float, sleeping: Boolean) {
        val walkP = now * 0.016f
        val breath = sin(now * (if (sleeping) 0.002f else 0.004f))
        val chew = if (act == Act.EAT && actTime(now) >= 0L) sin(now * 0.03f) else 0f
        val happy = if (mood == Mood.HAPPY) 1f else 0f
        val droop = if (mood == Mood.SAD || mood == Mood.TIRED) 1f else 0f
        var k = 0
        for (j in 0..MESH_H) {
            val v = j / MESH_H.toFloat()
            val top = 1f - v                           // 1 ở đỉnh đầu, 0 ở chân
            for (i in 0..MESH_W) {
                val u = i / MESH_W.toFloat()
                var x = -w / 2f + u * w
                var y = -h + v * h
                y += breath * 0.012f * h * top           // thở
                y += chew * 0.03f * h * top * top        // gật gù khi ăn
                y += droop * 0.04f * h * top             // xệ khi buồn, mệt
                x += happy * sin(now * 0.012f + v * 3f) * 0.025f * w * top   // lắc lư khi vui
                if (mood == Mood.HUNGRY) x += sin(now * 0.05f + v * 4f) * 0.008f * w
                when (motion) {
                    "bounce" -> {
                        val sq = if (walking) sin(walkP * 1.25f) else breath * 0.3f
                        x *= 1f - 0.06f * sq
                        y *= 1f + 0.09f * sq
                        x += sin(now * 0.011f + v * 5f) * 0.012f * w * top * (if (walking) 1.5f else 0.6f)
                    }
                    "fly" -> {
                        val sp = if (walking) 0.008f else 0.004f
                        y += sin(now * sp + u * 5.5f) * (if (walking) 0.055f else 0.03f) * h
                        x += sin(now * sp * 0.9f + v * 4f) * 0.02f * w * (if (walking) 1.4f else 1f)
                    }
                    else -> if (walking) {
                        x += sin(walkP) * 0.045f * w * top
                        val foot = ((v - 0.78f) / 0.22f).coerceIn(0f, 1f)
                        if (foot > 0f) {
                            val leg = if (u < 0.5f) sin(walkP) else sin(walkP + pi)
                            y -= max(0f, leg) * 0.075f * h * foot
                            x += leg * 0.04f * w * foot
                        }
                    }
                }
                mesh[k++] = x
                mesh[k++] = y
            }
        }
        c.drawBitmapMesh(bmp, MESH_W, MESH_H, mesh, 0, null, 0, spritePaint)
    }

    private fun drawCat(c: Canvas, now: Long, lift: Float) {
        c.save()
        c.translate(50f, 0f)
        c.scale(faceScale, 1f)
        c.translate(-50f, lift)

        // đuôi
        val wag = sin(now * (if (mood == Mood.HAPPY) 0.012f else 0.005f)) * 7f
        path.reset()
        path.moveTo(66f, 84f)
        path.quadTo(90f, 84f + wag * 0.3f, 86f, 62f + wag)
        ln.strokeWidth = 7.5f; ln.color = ink; c.drawPath(path, ln)
        ln.strokeWidth = 5f; ln.color = body; c.drawPath(path, ln)
        ln.strokeWidth = 1.6f; ln.color = ink

        // thân, bụng
        oval(c, 29f, 58f, 71f, 92f, body)
        oval(c, 38f, 67f, 62f, 90f, belly, false)

        // chân, tay
        val ph = now * 0.02f
        val lf = if (walking) max(0f, sin(ph)) * -5f else 0f
        val rt = if (walking) max(0f, sin(ph + pi)) * -5f else 0f
        oval(c, 33f, 88f + lf, 47f, 96f + lf, body)
        oval(c, 53f, 88f + rt, 67f, 96f + rt, body)
        val arm = if (walking) sin(ph) * 5f else if (mood == Mood.HAPPY) sin(now * 0.01f) * 4f else 0f
        oval(c, 24f, 68f + arm, 34f, 80f + arm, body)
        oval(c, 66f, 68f - arm, 76f, 80f - arm, body)

        // tai, đầu
        ear(c, 26f, 24f, 30f, 4f, 44f, 15f)
        ear(c, 74f, 24f, 70f, 4f, 56f, 15f)
        oval(c, 22f, 12f, 78f, 68f, body)

        // má hồng
        fill.color = Color.argb(140, 255, 150, 160)
        c.drawCircle(32f, 49f, 4.5f, fill)
        c.drawCircle(68f, 49f, 4.5f, fill)

        // mắt, mũi, miệng, ria
        val blink = (now % 3600L) < 140L
        eye(c, 40f, 40f, blink)
        eye(c, 60f, 40f, blink)
        if (mood == Mood.SAD) {
            c.drawLine(34f, 31f, 44f, 34f, ln)
            c.drawLine(66f, 31f, 56f, 34f, ln)
            fill.color = Color.parseColor("#6EC6FF")
            c.drawCircle(38f, 49f, 1.8f, fill)
        }
        fill.color = pink
        c.drawCircle(50f, 46f, 1.8f, fill)
        mouth(c, now)
        ln.strokeWidth = 1f
        c.drawLine(22f, 46f, 31f, 47f, ln); c.drawLine(22f, 51f, 31f, 50f, ln)
        c.drawLine(78f, 46f, 69f, 47f, ln); c.drawLine(78f, 51f, 69f, 50f, ln)
        ln.strokeWidth = 1.6f
        c.restore()
    }

    // ================= RỒNG CHIBI =================

    /** Một lọn bờm/râu trắng bay: từ (x,y) cong tới (x+dx, y+dy). */
    private fun tuft(c: Canvas, x: Float, y: Float, dx: Float, dy: Float, w: Float) {
        path.reset()
        path.moveTo(x - w, y)
        path.quadTo(x + dx * 0.4f - w, y + dy * 0.7f, x + dx, y + dy)
        path.quadTo(x + dx * 0.5f + w, y + dy * 0.4f, x + w, y)
        path.close()
        fill.color = Color.argb(240, 255, 255, 255)
        c.drawPath(path, fill)
        ln.strokeWidth = 0.8f
        ln.color = Color.parseColor("#BCD3D6")
        c.drawPath(path, ln)
        ln.strokeWidth = 1.6f
        ln.color = ink
    }

    /** Sừng bạc có nhánh. sign = -1 trái, +1 phải. */
    private fun antler(c: Canvas, sign: Float, sway: Float) {
        val bx = 50f + sign * 10f
        path.reset()
        path.moveTo(bx, 21f)
        path.quadTo(bx + sign * 9f, 12f, bx + sign * 5f + sway, 1.5f)
        path.moveTo(bx + sign * 5.5f, 11f)
        path.quadTo(bx + sign * 11f, 9f, bx + sign * 16f, 7f - sway * 0.3f)
        ln.strokeWidth = 4.2f; ln.color = ink2; c.drawPath(path, ln)
        ln.strokeWidth = 2.5f; ln.color = Color.parseColor("#D6DEE4"); c.drawPath(path, ln)
        ln.strokeWidth = 1.6f; ln.color = ink
    }

    /** Vây trong suốt ánh cầu vồng ở hai bên đầu. */
    private fun finLeaf(c: Canvas, sign: Float, flap: Float) {
        val x0 = 50f + sign * 23f
        path.reset()
        path.moveTo(x0, 37f)
        path.quadTo(50f + sign * 41f, 22f - flap, 50f + sign * 43f, 38f - flap * 0.5f)
        path.quadTo(50f + sign * 36f, 47f, x0, 44f)
        path.close()
        fill.color = Color.argb(150, 200, 245, 240)
        c.drawPath(path, fill)
        fill.color = Color.argb(90, 225, 205, 255)
        c.save()
        c.scale(0.7f, 0.7f, x0, 41f)
        c.drawPath(path, fill)
        c.restore()
        ln.strokeWidth = 0.9f; ln.color = Color.parseColor("#7FC6C0")
        c.drawPath(path, ln)
        ln.strokeWidth = 1.6f; ln.color = ink
    }

    private fun dragonEye(c: Canvas, x: Float, y: Float, blink: Boolean) {
        val glow = lerp(dragonAccent, Color.parseColor("#0A9E8E"), 0.35f)
        ln.color = ink2
        when {
            mood == Mood.SLEEP || blink -> {
                rf.set(x - 5f, y - 3f, x + 5f, y + 5f)
                c.drawArc(rf, 0f, 180f, false, ln)
            }
            mood == Mood.HAPPY -> {
                rf.set(x - 5f, y - 2f, x + 5f, y + 8f)
                c.drawArc(rf, 180f, 180f, false, ln)
            }
            mood == Mood.TIRED -> {
                fill.color = Color.argb(70, Color.red(glow), Color.green(glow), Color.blue(glow))
                c.drawCircle(x, y + 1f, 6f, fill)
                rf.set(x - 4.2f, y - 0.5f, x + 4.2f, y + 3f)
                fill.color = glow
                c.drawOval(rf, fill)
            }
            else -> {
                fill.color = Color.argb(70, Color.red(glow), Color.green(glow), Color.blue(glow))
                c.drawCircle(x, y, 8f, fill)
                rf.set(x - 4.8f, y - 6f, x + 4.8f, y + 6f)
                fill.color = glow
                c.drawOval(rf, fill)
                rf.set(x - 2f + gazeCur * 1.6f, y - 4f, x + 2f + gazeCur * 1.6f, y + 4.2f)
                fill.color = Color.parseColor("#16323A")
                c.drawOval(rf, fill)
                fill.color = Color.WHITE
                c.drawCircle(x + 1.7f, y - 2.6f, 1.6f, fill)
                c.drawCircle(x - 1.6f, y + 2.4f, 0.8f, fill)
            }
        }
        ln.color = ink
    }

    private fun dragonMouth(c: Canvas, now: Long, at: Long) {
        val eating = at >= 0L && act == Act.EAT
        val open = when {
            eating -> 3f + (sin(now * 0.03f) + 1f) * 4f
            mood == Mood.HAPPY -> 8f
            mood == Mood.HUNGRY -> 9f
            else -> 0f
        }
        ln.color = ink2
        if (open > 0f) {
            rf.set(43f, 50f, 57f, 50f + open)
            fill.color = Color.parseColor("#7A3B4A")
            c.drawOval(rf, fill)
            // răng nanh
            fill.color = Color.WHITE
            path.reset()
            path.moveTo(44.5f, 51f); path.lineTo(46.5f, 51f); path.lineTo(45.5f, 54.5f); path.close()
            path.moveTo(53.5f, 51f); path.lineTo(55.5f, 51f); path.lineTo(54.5f, 54.5f); path.close()
            c.drawPath(path, fill)
        } else if (mood == Mood.SAD) {
            rf.set(44f, 54f, 56f, 61f)
            c.drawArc(rf, 180f, 180f, false, ln)
        } else {
            rf.set(44f, 50f, 56f, 57f)
            c.drawArc(rf, 0f, 180f, false, ln)
        }
        ln.color = ink
    }

    private fun drawDragon(c: Canvas, now: Long, lift: Float, at: Long) {
        val sleeping = mood == Mood.SLEEP
        val speed = if (walking) 0.012f else if (sleeping) 0.0015f else 0.005f
        val amp = if (sleeping) 0.8f else if (walking) 3.4f else 2.2f
        val ph = now * speed

        c.save()
        c.translate(50f, 0f)
        c.scale(faceScale, 1f)
        c.translate(-50f, lift)

        // thân uốn lượn: các đốt tròn nối từ đuôi lên cổ, vòng viền tạo thành vảy
        val n = 16
        ln.strokeWidth = 1.1f
        ln.color = ink2
        for (i in n downTo 0) {
            val t = i / n.toFloat()
            val w = sin(ph * 3f - t * 7f) * amp * (0.3f + t)
            val x = bez(t, 50f, 86f, 36f, 12f) + w * 0.6f
            val y = bez(t, 60f, 64f, 104f, 70f) + w
            val r = 9.5f - 6f * t
            fill.color = lerp(dragonBody, dragonAccent, t * 0.8f)
            c.drawCircle(x, y, r, fill)
            c.drawCircle(x, y, r, ln)
            fill.color = Color.argb(110, 140, 240, 225)
            c.drawCircle(x - r * 0.25f, y - r * 0.3f, r * 0.32f, fill)
            // vây lưng
            if (i in 3..13 && i % 2 == 1) {
                tuft(c, x, y - r * 0.9f, -2f + sin(ph * 2f + i) * 2f, -7f, 2.2f)
            }
        }
        // chùm lông đuôi
        run {
            val tx = bez(1f, 50f, 86f, 36f, 12f)
            val ty = bez(1f, 60f, 64f, 104f, 70f)
            val sw = sin(ph * 3f) * 3f
            tuft(c, tx, ty, -9f + sw, -7f, 2.6f)
            tuft(c, tx, ty, -10f + sw, 1f, 2.6f)
            tuft(c, tx, ty, -6f + sw, 8f, 2.4f)
        }

        // móng vuốt phía trước
        val step = if (walking) sin(now * 0.02f) * 2.5f else 0f
        for (side in 0..1) {
            val px = if (side == 0) 38f else 62f
            val py = 73f + (if (side == 0) step else -step)
            rf.set(px - 5f, py - 3.5f, px + 5f, py + 4f)
            fill.color = dragonBody
            c.drawOval(rf, fill)
            ln.strokeWidth = 1.1f; ln.color = ink2
            c.drawOval(rf, ln)
            ln.strokeWidth = 1.3f; ln.color = Color.parseColor("#9AA9B0")
            for (k in -1..1) c.drawLine(px + k * 2.6f, py + 3.5f, px + k * 3.4f, py + 7f, ln)
            ln.strokeWidth = 1.6f; ln.color = ink
        }

        // bờm trắng bay sau đầu, râu cằm
        val sway = sin(ph * 2f)
        tuft(c, 28f, 22f, -16f + sway * 3f, -5f, 3f)
        tuft(c, 24f, 32f, -21f + sway * 3f, 3f, 3.2f)
        tuft(c, 26f, 44f, -18f + sway * 3f, 14f, 3f)
        tuft(c, 72f, 22f, 16f - sway * 3f, -5f, 3f)
        tuft(c, 76f, 32f, 21f - sway * 3f, 3f, 3.2f)
        tuft(c, 74f, 44f, 18f - sway * 3f, 14f, 3f)
        tuft(c, 46f, 17f, -5f + sway * 2f, -9f, 2.5f)
        tuft(c, 54f, 17f, 5f - sway * 2f, -9f, 2.5f)

        // vây ánh cầu vồng bên đầu
        val flap = sin(now * (if (walking) 0.02f else 0.006f)) * 3f
        finLeaf(c, -1f, flap)
        finLeaf(c, 1f, flap)

        // sừng
        antler(c, -1f, sway * 1.2f)
        antler(c, 1f, -sway * 1.2f)

        // đầu
        ln.strokeWidth = 1.2f; ln.color = ink2
        rf.set(26f, 15f, 74f, 58f)
        fill.color = lerp(dragonBody, Color.WHITE, 0.4f)
        c.drawOval(rf, fill)
        c.drawOval(rf, ln)
        // mõm
        rf.set(37f, 41f, 63f, 58f)
        fill.color = Color.WHITE
        c.drawOval(rf, fill)
        c.drawOval(rf, ln)
        fill.color = ink2
        c.drawCircle(46f, 47f, 0.9f, fill)
        c.drawCircle(54f, 47f, 0.9f, fill)
        ln.strokeWidth = 1.6f; ln.color = ink

        // má hồng, mắt
        fill.color = Color.argb(110, 255, 170, 185)
        c.drawCircle(31f, 46f, 4.2f, fill)
        c.drawCircle(69f, 46f, 4.2f, fill)
        val blink = (now % 4000L) < 150L
        dragonEye(c, 39f, 35f, blink)
        dragonEye(c, 61f, 35f, blink)
        if (mood == Mood.SAD) {
            ln.color = ink2
            c.drawLine(33f, 26f, 43f, 29f, ln)
            c.drawLine(67f, 26f, 57f, 29f, ln)
            ln.color = ink
            fill.color = Color.parseColor("#6EC6FF")
            c.drawCircle(36f, 44f, 1.8f, fill)
        }
        dragonMouth(c, now, at)

        // hai sợi râu dài bay lượn
        for (sign in intArrayOf(-1, 1)) {
            val sx = 50f + sign * 7f
            val wv = sin(ph * 2f + sign) * 6f
            path.reset()
            path.moveTo(sx, 50f)
            path.quadTo(50f + sign * 27f, 51f + wv, 50f + sign * 44f, 41f + wv * 1.4f)
            ln.strokeWidth = 2.2f; ln.color = ink2; c.drawPath(path, ln)
            ln.strokeWidth = 1.1f; ln.color = Color.parseColor("#F4FAFB"); c.drawPath(path, ln)
        }
        ln.strokeWidth = 1.6f; ln.color = ink

        // viên ngọc rồng phát sáng, nhịp thở
        if (!sleeping) {
            val pr = 4.2f + sin(now * 0.006f) * 0.8f
            val gx = 86f
            val gy = 66f + sin(now * 0.004f) * 2f
            fill.color = Color.argb(50, 160, 245, 255)
            c.drawCircle(gx, gy, pr + 4.5f, fill)
            fill.color = Color.argb(90, 190, 250, 255)
            c.drawCircle(gx, gy, pr + 2.2f, fill)
            fill.color = Color.parseColor("#EFFFFF")
            c.drawCircle(gx, gy, pr, fill)
            fill.color = Color.WHITE
            c.drawCircle(gx - 1.2f, gy - 1.3f, 1.3f, fill)
        }
        c.restore()
    }
}
