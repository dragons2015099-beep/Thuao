package com.example.thuao

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Hành động có hoạt hình riêng khi bấm Cho ăn / Chơi / Tắm. */
enum class Act { NONE, EAT, PLAY, BATH }

/**
 * Vẽ một bé thú: mèo chibi, rồng chibi (vẽ bằng mã), hoặc ảnh nhân vật do bạn thêm.
 * Mọi bé đều có hiệu ứng ăn, chơi bóng, tắm bong bóng, ngủ, nhả tim.
 */
class PetView(ctx: Context) : View(ctx) {
    var mood = Mood.NORMAL
    var walking = false
    var facing = 1

    private var sprite: Bitmap? = null
    private var isDragon = false
    private var hopStart = -100000L
    private var heartStart = -100000L
    private var spinStart = -100000L
    private var act = Act.NONE
    private var actStart = -100000L
    private var faceScale = 1f        // xoay người mượt khi đổi hướng
    private var squashAmt = 0f        // >0 bóp xuống khi tiếp đất, <0 giãn ra khi bật nhảy
    private var gaze = 0f
    private var gazeCur = 0f
    private var motion = "walk"
    private var faceLeft = false
    private val MESH_W = 8
    private val MESH_H = 14
    private val mesh = FloatArray((8 + 1) * (14 + 1) * 2)

    private var body = Color.parseColor("#FFD9A0")
    private var belly = Color.parseColor("#FFF1D6")
    private var dragonBody = Color.parseColor("#F2FAFA")
    private var dragonAccent = Color.parseColor("#9FD8D0")
    private var species = "cat"
    private var panda = false
    private var cow = false
    private var sheep = false
    private var cBody = Color.parseColor("#FFD9A0")
    private var cBelly = Color.parseColor("#FFF1D6")
    private var cLight = Color.WHITE
    private var cDark = Color.parseColor("#E5BF8C")
    private var cOutline = Color.parseColor("#8A5B3F")
    private var headShader: Shader? = null
    private var bodyShader: Shader? = null
    private var dragonHeadShader: Shader? = null
    private var auraShader: Shader? = null
    private val eyeInk = Color.parseColor("#2B1E1A")
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pink = Color.parseColor("#FFB3B8")
    private val ink = Color.parseColor("#4A3326")
    private val ink2 = Color.parseColor("#5E7C85")

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = ink
        strokeWidth = 1.6f
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val spritePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val grayFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0.35f) })
    private val path = Path()
    private val rf = RectF()
    private val dst = RectF()
    private val pi = Math.PI.toFloat()

    fun setLook(ctx: Context, look: String) {
        sprite = null
        isDragon = false
        when {
            look.startsWith("img:") -> sprite = Looks.bitmap(look.removePrefix("img:"))
            look.startsWith("dragon:") -> {
                isDragon = true
                val i = (look.removePrefix("dragon:").toIntOrNull() ?: 0).coerceIn(0, Looks.DRAGON_COLORS.size - 1)
                dragonBody = Color.parseColor(Looks.DRAGON_COLORS[i].second)
                dragonAccent = Color.parseColor(Looks.DRAGON_COLORS[i].third)
                dragonHeadShader = RadialGradient(
                    44f, 26f, 36f,
                    intArrayOf(Color.WHITE, lerp(dragonBody, Color.WHITE, 0.5f), dragonBody),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
                val ac = dragonAccent
                auraShader = RadialGradient(
                    50f, 50f, 50f,
                    intArrayOf(
                        Color.argb(80, Color.red(ac), Color.green(ac), Color.blue(ac)),
                        Color.argb(0, Color.red(ac), Color.green(ac), Color.blue(ac))
                    ),
                    null, Shader.TileMode.CLAMP
                )
            }
            look.startsWith("an:") -> {
                val parts = look.split(":")
                setAnimal(parts.getOrNull(1) ?: "cat", parts.getOrNull(2)?.toIntOrNull() ?: 0)
            }
            else -> setAnimal("cat", look.removePrefix("cat:").toIntOrNull() ?: 0)
        }
        invalidate()
    }

    /** Kiểu cử động ("walk" / "bounce" / "fly") và ảnh gốc có đang quay mặt sang trái không. */
    fun setStyle(m: String, left: Boolean) {
        motion = m
        faceLeft = left
    }

    fun hop() { hopStart = SystemClock.uptimeMillis() }

    fun hearts() {
        heartStart = SystemClock.uptimeMillis()
        if (isDragon) spinStart = heartStart
        hop()
    }

    fun doAct(a: Act) {
        act = a
        actStart = SystemClock.uptimeMillis()
    }

    /** Tiếp đất: bóp người xuống rồi bật lại. */
    fun landed(strength: Float) { squashAmt = strength.coerceIn(0f, 0.25f) }

    /** Bật nhảy: giãn người ra. */
    fun jumped() { squashAmt = -0.12f }

    /** Nhìn theo ngón tay: -1 (trái) đến 1 (phải), 0 là nhìn thẳng. */
    fun gazeTo(x: Float) { gaze = x.coerceIn(-1f, 1f) }

    private fun actTime(now: Long): Long {
        val t = now - actStart
        return if (act != Act.NONE && t in 0..2600) t else -1L
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = SystemClock.uptimeMillis()
        faceScale += (facing - faceScale) * 0.28f
        squashAmt *= 0.86f
        gazeCur += (gaze - gazeCur) * 0.2f
        val u = min(width, height) / 100f
        if (u > 0f) {
            c.save()
            c.translate((width - 100f * u) / 2f, height - 100f * u)
            c.scale(u, u)
            drawPet(c, now)
            c.restore()
        }
        postInvalidateOnAnimation()
    }

    private fun lerp(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    private fun bez(t: Float, a: Float, b: Float, c: Float, d: Float): Float {
        val u = 1f - t
        return u * u * u * a + 3f * u * u * t * b + 3f * u * t * t * c + t * t * t * d
    }

    private fun oval(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, outline: Boolean = true) {
        rf.set(l, t, r, b)
        fill.color = color
        c.drawOval(rf, fill)
        if (outline) c.drawOval(rf, ln)
    }

    private fun bubble(c: Canvas, s: String, x: Float, y: Float, size: Float) {
        txt.color = Color.BLACK
        txt.alpha = 255
        txt.textSize = size
        c.drawText(s, x, y, txt)
    }

    private fun drawPet(c: Canvas, now: Long) {
        val sleeping = mood == Mood.SLEEP
        val at = actTime(now)

        // bóng dưới chân (rồng thì bay trên mây)
        if (isDragon) {
            val dx = sin(now * 0.002f) * 2f
            fill.color = Color.argb(205, 255, 255, 255)
            c.drawCircle(28f + dx, 93f, 7f, fill)
            c.drawCircle(40f + dx, 95f, 9f, fill)
            c.drawCircle(54f + dx, 94f, 8.5f, fill)
            c.drawCircle(67f + dx, 93f, 7f, fill)
        } else {
            fill.color = Color.argb(50, 0, 0, 0)
            rf.set(26f, 92f, 74f, 99f)
            c.drawOval(rf, fill)
        }

        val dt = now - hopStart
        var hopY = if (dt in 0..520) -abs(sin(dt / 520f * pi)) * 20f else 0f
        if (at >= 0L && act == Act.PLAY) hopY = min(hopY, -abs(sin(at * 0.009f)) * 10f)
        val bob = when {
            sleeping -> sin(now * 0.002f) * 1.2f
            isDragon -> sin(now * 0.004f) * 3f
            walking -> abs(sin(now * 0.016f)) * -3f
            else -> sin(now * 0.004f) * 1f
        }

        val sp = sprite
        c.save()
        c.scale(1f + squashAmt, 1f - squashAmt, 50f, 96f)
        when {
            isDragon -> {
                val st = now - spinStart
                c.save()
                if (st in 0..800) c.rotate(st / 800f * 360f, 50f, 55f)
                drawDragon(c, now, hopY + bob, at)
                c.restore()
            }
            sp != null -> drawSprite(c, now, sp, hopY + bob, sleeping)
            species == "snake" -> drawSnake(c, now, hopY + bob)
            else -> drawAnimal(c, now, hopY + bob)
        }
        c.restore()

        drawEffects(c, now, at)

        // bẩn
        if (mood == Mood.DIRTY) {
            fill.color = Color.parseColor("#8B6B4A")
            c.drawCircle(38f, 56f, 2.2f, fill)
            c.drawCircle(62f, 66f, 2.6f, fill)
            c.drawCircle(47f, 82f, 2.2f, fill)
            c.drawCircle(58f, 40f, 1.8f, fill)
        }

        // biểu tượng nhu cầu
        when (mood) {
            Mood.HUNGRY -> bubble(c, "🍖", 88f, 12f, 15f)
            Mood.SAD -> bubble(c, "💧", 88f, 12f, 14f)
            Mood.TIRED -> bubble(c, "💤", 88f, 12f, 14f)
            Mood.DIRTY -> bubble(c, "🧼", 88f, 12f, 14f)
            else -> {}
        }
        if (sleeping) {
            for (i in 0..2) {
                val p = ((now / 900f) + i * 0.7f) % 2.1f
                txt.color = Color.parseColor("#5B6BC0")
                txt.alpha = (255 * (1f - p / 2.1f)).toInt().coerceIn(0, 255)
                txt.textSize = 8f + i * 3f
                c.drawText("z", 76f + p * 4f, 22f - p * 9f, txt)
            }
        }

        // tim bay lên khi được vuốt ve
        val hd = now - heartStart
        if (hd in 0..1200) {
            val t = hd / 1200f
            for (i in 0..2) {
                txt.color = Color.parseColor("#FF4D6D")
                txt.alpha = ((1f - t) * 255).toInt().coerceIn(0, 255)
                txt.textSize = 12f
                c.drawText("❤", 32f + i * 18f + sin(t * 6f + i) * 3f, 14f - t * 28f + i * 5f, txt)
            }
        }
    }

    /** Hiệu ứng ăn (miếng thịt bay vào miệng), chơi (quả bóng nảy), tắm (bong bóng xà phòng). */
    private fun drawEffects(c: Canvas, now: Long, at: Long) {
        if (at < 0L) return
        when (act) {
            Act.EAT -> {
                if (at < 1100L) {
                    val k = at / 1100f
                    bubble(c, "🍖", 82f - 28f * k, 18f + 28f * k, 13f)
                } else if (at < 1700L) {
                    bubble(c, "✨", 54f, 42f - (at - 1100L) / 40f, 12f)
                }
            }
            Act.PLAY -> {
                val x = 50f + sin(at * 0.006f) * 36f
                val y = 90f - abs(sin(at * 0.009f)) * 46f
                bubble(c, "⚽", x, y, 12f)
            }
            Act.BATH -> {
                for (i in 0..8) {
                    val x = 24f + i * 6f + sin(at * 0.004f + i) * 4f
                    val y = 94f - ((at * 0.03f + i * 13f) % 78f)
                    val r = 2.2f + (i % 3)
                    fill.color = Color.argb(140, 255, 255, 255)
                    c.drawCircle(x, y, r, fill)
                    ln.strokeWidth = 0.8f
                    ln.color = Color.argb(200, 120, 190, 230)
                    c.drawCircle(x, y, r, ln)
                    ln.strokeWidth = 1.6f
                    ln.color = ink
                }
            }
            else -> {}
        }
    }

    /**
     * Ảnh nhân vật: uốn lưới (mesh) để có cử động thật chứ không chỉ lật/lắc:
     * thở, nhún theo bước, chân luân phiên (kiểu "walk"), nảy dẻo (kiểu "bounce"), uốn sóng (kiểu "fly"),
     * gật gù khi ăn, rung khi đói, xệ xuống khi buồn, lắc lư khi vui.
     */
    private fun drawSprite(c: Canvas, now: Long, bmp: Bitmap, lift: Float, sleeping: Boolean) {
        val s = min(84f / bmp.width, 86f / bmp.height)
        val w = bmp.width * s
        val h = bmp.height * s
        c.save()
        c.translate(50f, 93f + lift)
        c.scale(if (faceLeft) -faceScale else faceScale, 1f)
        val rock = when {
            walking && motion == "walk" -> sin(now * 0.016f) * 2.5f
            walking -> sin(now * 0.012f) * 4f
            sleeping -> 12f
            mood == Mood.TIRED -> 5f
            else -> sin(now * 0.003f) * 1.5f
        } + gazeCur * 6f
        c.rotate(rock)
        spritePaint.alpha = if (sleeping) 190 else 255
        spritePaint.colorFilter = if (mood == Mood.SAD || mood == Mood.TIRED) grayFilter else null
        drawSpriteMesh(c, now, bmp, w, h, sleeping)
        c.restore()
    }

    private fun drawSpriteMesh(c: Canvas, now: Long, bmp: Bitmap, w: Float, h: Float, sleeping: Boolean) {
        val walkP = now * 0.016f
        val breath = sin(now * (if (sleeping) 0.002f else 0.004f))
        val chew = if (act == Act.EAT && actTime(now) >= 0L) sin(now * 0.03f) else 0f
        val happy = if (mood == Mood.HAPPY) 1f else 0f
        val droop = if (mood == Mood.SAD || mood == Mood.TIRED) 1f else 0f
        var k = 0
        for (j in 0..MESH_H) {
            val v = j / MESH_H.toFloat()
            val top = 1f - v                           // 1 ở đỉnh đầu, 0 ở chân
            for (i in 0..MESH_W) {
                val u = i / MESH_W.toFloat()
                var x = -w / 2f + u * w
                var y = -h + v * h
                y += breath * 0.012f * h * top           // thở
                y += chew * 0.03f * h * top * top        // gật gù khi ăn
                y += droop * 0.04f * h * top             // xệ khi buồn, mệt
                x += happy * sin(now * 0.012f + v * 3f) * 0.025f * w * top   // lắc lư khi vui
                if (mood == Mood.HUNGRY) x += sin(now * 0.05f + v * 4f) * 0.008f * w
                when (motion) {
                    "bounce" -> {
                        val sq = if (walking) sin(walkP * 1.25f) else breath * 0.3f
                        x *= 1f - 0.06f * sq
                        y *= 1f + 0.09f * sq
                        x += sin(now * 0.011f + v * 5f) * 0.012f * w * top * (if (walking) 1.5f else 0.6f)
                    }
                    "fly" -> {
                        val sp = if (walking) 0.008f else 0.004f
                        y += sin(now * sp + u * 5.5f) * (if (walking) 0.055f else 0.03f) * h
                        x += sin(now * sp * 0.9f + v * 4f) * 0.02f * w * (if (walking) 1.4f else 1f)
                    }
                    else -> if (walking) {
                        x += sin(walkP) * 0.045f * w * top
                        val foot = ((v - 0.78f) / 0.22f).coerceIn(0f, 1f)
                        if (foot > 0f) {
                            val leg = if (u < 0.5f) sin(walkP) else sin(walkP + pi)
                            y -= max(0f, leg) * 0.075f * h * foot
                            x += leg * 0.04f * w * foot
                        }
                    }
                }
                mesh[k++] = x
                mesh[k++] = y
            }
        }
        c.drawBitmapMesh(bmp, MESH_W, MESH_H, mesh, 0, null, 0, spritePaint)
    }

    // ================= THÚ CHIBI: mèo, thỏ, gấu/panda, cáo, chó =================

    private val padCol = Color.parseColor("#FF9FB0")
    private val darkPanda = Color.parseColor("#3A3A44")

    private fun setAnimal(sp: String, idx: Int) {
        species = sp
        val pal = Looks.palette(sp)
        val i = idx.coerceIn(0, pal.size - 1)
        panda = sp == "bear" && i == 1
        cow = sp == "ox" && i == 2
        sheep = sp == "goat" && i == 2
        cBody = Color.parseColor(pal[i].second)
        cBelly = Color.parseColor(pal[i].third)
        cLight = lerp(cBody, Color.WHITE, 0.45f)
        cDark = lerp(cBody, Color.parseColor("#6B4A3A"), 0.28f)
        cOutline = lerp(cBody, Color.parseColor("#4A2F27"), 0.62f)
        headShader = RadialGradient(
            42f, 28f, 42f, intArrayOf(cLight, cBody, cDark), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        bodyShader = LinearGradient(0f, 56f, 0f, 94f, cLight, cDark, Shader.TileMode.CLAMP)
    }

    private fun triEar(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, tipDark: Boolean) {
        path.reset()
        path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
        fill.color = if (panda) darkPanda else cBody
        c.drawPath(path, fill)
        c.drawPath(path, ln)
        val mx = (x1 + x2 + x3) / 3f
        val my = (y1 + y2 + y3) / 3f
        path.reset()
        path.moveTo(mx + (x1 - mx) * 0.55f, my + (y1 - my) * 0.55f)
        path.lineTo(mx + (x2 - mx) * 0.55f, my + (y2 - my) * 0.55f)
        path.lineTo(mx + (x3 - mx) * 0.55f, my + (y3 - my) * 0.55f)
        path.close()
        fill.color = if (species == "cat") Color.parseColor("#FFB3B8") else cBelly
        c.drawPath(path, fill)
        if (tipDark) {
            path.reset()
            path.moveTo(x2, y2)
            path.lineTo(x2 + (x1 - x2) * 0.4f, y2 + (y1 - y2) * 0.4f)
            path.lineTo(x2 + (x3 - x2) * 0.4f, y2 + (y3 - y2) * 0.4f)
            path.close()
            fill.color = Color.parseColor("#5B3A2B")
            c.drawPath(path, fill)
        }
    }

    private fun drawEars(c: Canvas, now: Long) {
        val sway = sin(now * 0.004f) * 1.5f
        when (species) {
            "mouse" -> {
                for (sg in intArrayOf(-1, 1)) {
                    val ex = 50f + sg * 22f
                    fill.color = cBody
                    c.drawCircle(ex, 20f, 10.5f, fill)
                    c.drawCircle(ex, 20f, 10.5f, ln)
                    fill.color = Color.parseColor("#FFC4CF")
                    c.drawCircle(ex, 20.5f, 6.2f, fill)
                }
            }
            "tiger" -> {
                for (sg in intArrayOf(-1, 1)) {
                    val ex = 50f + sg * 21f
                    fill.color = cBody
                    c.drawCircle(ex, 19f, 8.5f, fill)
                    c.drawCircle(ex, 19f, 8.5f, ln)
                    fill.color = cBelly
                    c.drawCircle(ex, 19.5f, 4.5f, fill)
                }
            }
            "monkey" -> {
                for (sg in intArrayOf(-1, 1)) {
                    val ex = 50f + sg * 29f
                    fill.color = cBody
                    c.drawCircle(ex, 40f, 8.5f, fill)
                    c.drawCircle(ex, 40f, 8.5f, ln)
                    fill.color = Color.parseColor("#FFD9C2")
                    c.drawCircle(ex, 40.5f, 5f, fill)
                }
            }
            "ox" -> {
                for (sg in intArrayOf(-1, 1)) {
                    path.reset()
                    path.moveTo(50f + sg * 13f, 18f)
                    path.quadTo(50f + sg * 22f, 16f, 50f + sg * 21f, 3f)
                    path.quadTo(50f + sg * 14f, 10f, 50f + sg * 9f, 16f)
                    path.close()
                    fill.color = Color.parseColor("#F8E8C8")
                    c.drawPath(path, fill)
                    c.drawPath(path, ln)
                    val ex = 50f + sg * 29f
                    c.save()
                    c.rotate(sg * 18f, ex, 33f)
                    rf.set(ex - 10f, 28f, ex + 10f, 38f)
                    fill.color = cDark
                    c.drawOval(rf, fill)
                    c.drawOval(rf, ln)
                    c.restore()
                }
            }
            "goat" -> {
                if (sheep) {
                    fill.color = Color.WHITE
                    val puffs = listOf(28f to 24f, 36f to 13f, 50f to 9f, 64f to 13f, 72f to 24f, 24f to 38f, 76f to 38f)
                    for (p in puffs) {
                        c.drawCircle(p.first, p.second, 10f, fill)
                        c.drawCircle(p.first, p.second, 10f, ln)
                    }
                }
                for (sg in intArrayOf(-1, 1)) {
                    if (!sheep) {
                        path.reset()
                        path.moveTo(50f + sg * 9f, 16f)
                        path.quadTo(50f + sg * 12f, 4f, 50f + sg * 22f, 3f)
                        path.quadTo(50f + sg * 16f, 8f, 50f + sg * 15f, 17f)
                        path.close()
                        fill.color = Color.parseColor("#E9D9B8")
                        c.drawPath(path, fill)
                        c.drawPath(path, ln)
                    }
                    val ex = 50f + sg * 28f
                    c.save()
                    c.rotate(sg * 25f, ex, 34f)
                    rf.set(ex - 9f, 30f, ex + 9f, 38f)
                    fill.color = if (sheep) Color.parseColor("#5A5663") else cBody
                    c.drawOval(rf, fill)
                    c.drawOval(rf, ln)
                    c.restore()
                }
            }
            "horse" -> {
                triEar(c, 31f, 24f, 34f, 3f, 46f, 15f, false)
                triEar(c, 69f, 24f, 66f, 3f, 54f, 15f, false)
            }
            "pig" -> {
                triEar(c, 27f, 25f, 25f, 6f, 44f, 15f, false)
                triEar(c, 73f, 25f, 75f, 6f, 56f, 15f, false)
            }
            "rooster" -> {
                for (cx in floatArrayOf(43f, 50f, 57f)) {
                    val cy = if (cx == 50f) 9f else 12f
                    fill.color = Color.parseColor("#E5484D")
                    c.drawCircle(cx, cy, 5f, fill)
                    c.drawCircle(cx, cy, 5f, ln)
                }
            }
            "bunny" -> {
                for (sg in intArrayOf(-1, 1)) {
                    val ex = 50f + sg * 14f
                    c.save()
                    c.rotate(sg * (10f + sway * (if (walking) 3f else 1f)), ex, 30f)
                    rf.set(ex - 6.5f, 1f, ex + 6.5f, 31f)
                    fill.color = cBody
                    c.drawOval(rf, fill)
                    c.drawOval(rf, ln)
                    rf.set(ex - 3.4f, 5f, ex + 3.4f, 27f)
                    fill.color = Color.parseColor("#FFC4CF")
                    c.drawOval(rf, fill)
                    c.restore()
                }
            }
            "bear" -> {
                for (sg in intArrayOf(-1, 1)) {
                    val ex = 50f + sg * 21f
                    fill.color = if (panda) darkPanda else cBody
                    c.drawCircle(ex, 19f, 8.5f, fill)
                    c.drawCircle(ex, 19f, 8.5f, ln)
                    fill.color = if (panda) Color.parseColor("#55555F") else cBelly
                    c.drawCircle(ex, 19.5f, 4.5f, fill)
                }
            }
            "fox" -> {
                triEar(c, 25f, 27f, 29f, 2f, 46f, 16f, true)
                triEar(c, 75f, 27f, 71f, 2f, 54f, 16f, true)
            }
            "dog" -> {
                val sw = sway * (if (walking) 2.5f else 1f)
                for (sg in intArrayOf(-1, 1)) {
                    path.reset()
                    path.moveTo(50f + sg * 24f, 20f)
                    path.quadTo(50f + sg * (42f + sw), 20f, 50f + sg * 40f, 46f)
                    path.quadTo(50f + sg * 38f, 56f, 50f + sg * 28f, 50f)
                    path.quadTo(50f + sg * 20f, 40f, 50f + sg * 21f, 26f)
                    path.close()
                    fill.color = cDark
                    c.drawPath(path, fill)
                    c.drawPath(path, ln)
                }
            }
            else -> {
                triEar(c, 26f, 24f, 30f, 3f, 45f, 15f, false)
                triEar(c, 74f, 24f, 70f, 3f, 55f, 15f, false)
            }
        }
    }

    private fun strokeTail(c: Canvas, outerW: Float) {
        ln.strokeWidth = outerW; ln.color = cOutline; c.drawPath(path, ln)
        ln.strokeWidth = outerW - 2.6f; ln.color = cBody; c.drawPath(path, ln)
        ln.strokeWidth = 1.4f; ln.color = cOutline
    }

    private fun drawTail(c: Canvas, now: Long) {
        val wag = sin(now * (if (mood == Mood.HAPPY) 0.012f else 0.005f)) * 7f
        when (species) {
            "mouse" -> {
                path.reset()
                path.moveTo(66f, 88f)
                path.quadTo(94f, 94f + wag * 0.3f, 90f, 66f + wag)
                ln.strokeWidth = 3.6f; ln.color = cOutline; c.drawPath(path, ln)
                ln.strokeWidth = 1.8f; ln.color = Color.parseColor("#FFB5C5"); c.drawPath(path, ln)
                ln.strokeWidth = 1.4f; ln.color = cOutline
            }
            "ox" -> {
                path.reset()
                path.moveTo(66f, 86f)
                path.quadTo(84f, 88f, 82f, 70f + wag)
                ln.strokeWidth = 3.6f; ln.color = cOutline; c.drawPath(path, ln)
                ln.strokeWidth = 1.8f; ln.color = cBody; c.drawPath(path, ln)
                ln.strokeWidth = 1.4f; ln.color = cOutline
                fill.color = cDark
                c.drawCircle(82f, 69f + wag, 3.6f, fill)
                c.drawCircle(82f, 69f + wag, 3.6f, ln)
            }
            "tiger" -> {
                path.reset()
                path.moveTo(66f, 84f)
                path.quadTo(90f, 84f + wag * 0.3f, 86f, 62f + wag)
                strokeTail(c, 7.6f)
                ln.strokeWidth = 2.2f
                ln.color = Color.parseColor("#5B3A2B")
                for (t in floatArrayOf(0.35f, 0.58f, 0.8f)) {
                    val u = 1f - t
                    val x = u * u * 66f + 2f * u * t * 90f + t * t * 86f
                    val y = u * u * 84f + 2f * u * t * (84f + wag * 0.3f) + t * t * (62f + wag)
                    c.drawLine(x - 3f, y + 1.5f, x + 3f, y - 1.5f, ln)
                }
                ln.strokeWidth = 1.4f
                ln.color = cOutline
            }
            "horse" -> {
                path.reset()
                path.moveTo(66f, 84f)
                path.quadTo(92f, 86f + wag * 0.3f, 84f, 60f + wag)
                ln.strokeWidth = 9f; ln.color = cOutline; c.drawPath(path, ln)
                ln.strokeWidth = 6.4f; ln.color = maneColor(); c.drawPath(path, ln)
                ln.strokeWidth = 1.4f; ln.color = cOutline
            }
            "goat" -> {
                fill.color = cBody
                c.drawCircle(68f, 87f, 3.6f, fill)
                c.drawCircle(68f, 87f, 3.6f, ln)
            }
            "monkey" -> {
                path.reset()
                path.moveTo(66f, 87f)
                path.cubicTo(98f, 92f, 100f, 58f, 86f, 62f)
                path.cubicTo(78f, 64f, 78f, 74f, 85f, 73f)
                strokeTail(c, 7f)
            }
            "pig" -> {
                path.reset()
                path.moveTo(66f, 86f)
                path.cubicTo(78f, 84f, 78f, 76f, 72f, 78f)
                path.cubicTo(68f, 80f, 72f, 84f, 76f, 82f)
                ln.strokeWidth = 3.4f; ln.color = cOutline; c.drawPath(path, ln)
                ln.strokeWidth = 1.8f; ln.color = cBody; c.drawPath(path, ln)
                ln.strokeWidth = 1.4f; ln.color = cOutline
            }
            "rooster" -> {
                val cols = intArrayOf(Color.parseColor("#E5484D"), Color.parseColor("#3FB68B"), Color.parseColor("#F59E0B"))
                val angs = floatArrayOf(-30f, 0f, 30f)
                for (i in 0..2) {
                    c.save()
                    c.rotate(angs[i] + wag * 0.6f, 68f, 86f)
                    rf.set(63f, 52f, 73f, 86f)
                    fill.color = cols[i]
                    c.drawOval(rf, fill)
                    c.drawOval(rf, ln)
                    c.restore()
                }
            }
            "bunny" -> {
                fill.color = cLight
                c.drawCircle(68f, 86f, 6.2f, fill)
                c.drawCircle(68f, 86f, 6.2f, ln)
            }
            "bear" -> {
                fill.color = if (panda) darkPanda else cBody
                c.drawCircle(68f, 87f, 4.6f, fill)
                c.drawCircle(68f, 87f, 4.6f, ln)
            }
            "fox" -> {
                path.reset()
                path.moveTo(66f, 87f)
                path.quadTo(97f, 90f + wag * 0.3f, 88f, 57f + wag)
                strokeTail(c, 12f)
                fill.color = cBelly
                c.drawCircle(88f, 57f + wag, 5.4f, fill)
            }
            "dog" -> {
                path.reset()
                path.moveTo(66f, 86f)
                path.quadTo(85f, 85f + wag * 0.3f, 82f, 70f + wag)
                strokeTail(c, 8f)
            }
            else -> {
                path.reset()
                path.moveTo(66f, 84f)
                path.quadTo(90f, 84f + wag * 0.3f, 86f, 62f + wag)
                strokeTail(c, 7.6f)
            }
        }
    }

    private fun aEye(c: Canvas, x: Float, y: Float, blink: Boolean) {
        val gx = gazeCur * 1.6f
        ln.color = eyeInk
        ln.strokeWidth = 1.6f
        when {
            mood == Mood.SLEEP || blink -> {
                rf.set(x - 5f, y - 3f, x + 5f, y + 4f)
                c.drawArc(rf, 15f, 150f, false, ln)
            }
            mood == Mood.HAPPY -> {
                rf.set(x - 5f, y - 2f, x + 5f, y + 7f)
                c.drawArc(rf, 200f, 140f, false, ln)
            }
            else -> {
                rf.set(x - 4.7f + gx, y - 6f, x + 4.7f + gx, y + 6f)
                fill.color = eyeInk
                c.drawOval(rf, fill)
                rf.set(x - 3.4f + gx, y - 1f, x + 3.4f + gx, y + 5.2f)
                fill.color = Color.argb(190, 150, 95, 70)
                c.drawOval(rf, fill)
                fill.color = Color.WHITE
                c.drawCircle(x - 1.5f + gx, y - 2.6f, 2.0f, fill)
                c.drawCircle(x + 1.9f + gx, y + 2.4f, 0.9f, fill)
                if (mood == Mood.TIRED) {
                    fill.color = cBody
                    c.drawRect(x - 6.2f, y - 7.5f, x + 6.2f, y - 0.5f, fill)
                    c.drawLine(x - 5f, y - 0.5f, x + 5f, y - 0.5f, ln)
                } else {
                    rf.set(x - 5.4f + gx, y - 6.8f, x + 5.4f + gx, y + 1f)
                    c.drawArc(rf, 195f, 150f, false, ln)
                }
            }
        }
        ln.color = cOutline
        ln.strokeWidth = 1.4f
    }

    private fun aMouth(c: Canvas, now: Long) {
        ln.color = Color.parseColor("#5A3A33")
        ln.strokeWidth = 1.3f
        if (actTime(now) >= 0L && act == Act.EAT) {
            val chew = (sin(now * 0.03f) + 1f) / 2f
            rf.set(45f, 52.6f, 55f, 54.6f + chew * 7f)
            fill.color = Color.parseColor("#7A3B3B")
            c.drawOval(rf, fill)
        } else {
            when (mood) {
                Mood.HAPPY -> {
                    rf.set(43.5f, 52.4f, 56.5f, 62f)
                    fill.color = Color.parseColor("#E86A7A")
                    c.drawArc(rf, 0f, 180f, true, fill)
                    fill.color = Color.parseColor("#FF9FB0")
                    c.drawCircle(50f, 59.8f, 2.6f, fill)
                    c.drawArc(rf, 0f, 180f, true, ln)
                }
                Mood.HUNGRY -> {
                    rf.set(46.5f, 52.6f, 53.5f, 60f)
                    fill.color = Color.parseColor("#7A3B3B")
                    c.drawOval(rf, fill)
                }
                Mood.SAD -> {
                    rf.set(45f, 56f, 55f, 62f)
                    c.drawArc(rf, 200f, 140f, false, ln)
                }
                Mood.TIRED, Mood.DIRTY -> c.drawLine(46.5f, 55f, 53.5f, 55f, ln)
                else -> {
                    c.drawLine(50f, 52.3f, 50f, 55f, ln)
                    rf.set(44.6f, 52.6f, 50f, 57.6f); c.drawArc(rf, 0f, 180f, false, ln)
                    rf.set(50f, 52.6f, 55.4f, 57.6f); c.drawArc(rf, 0f, 180f, false, ln)
                }
            }
        }
        ln.color = cOutline
        ln.strokeWidth = 1.4f
    }

    private fun drawAnimal(c: Canvas, now: Long, lift: Float) {
        c.save()
        c.translate(50f, 0f)
        c.scale(faceScale, 1f)
        c.translate(-50f, lift)
        ln.color = cOutline
        ln.strokeWidth = 1.4f
        val limb = when {
            panda -> darkPanda
            species == "rooster" -> Color.parseColor("#FFB02E")
            else -> cBody
        }
        val armCol = if (panda) darkPanda else cBody
        val ph = now * 0.02f

        drawTail(c, now)
        drawEars(c, now)

        // thân + bụng
        shade.shader = bodyShader
        rf.set(32f, 56f, 68f, 93f)
        c.drawOval(rf, shade)
        shade.shader = null
        c.drawOval(rf, ln)
        fill.color = cBelly
        rf.set(40f, 65f, 60f, 90f)
        c.drawOval(rf, fill)

        // chân (có đệm thịt hồng)
        val lf = if (walking) max(0f, sin(ph)) * -5f else 0f
        val rt = if (walking) max(0f, sin(ph + pi)) * -5f else 0f
        for (side in 0..1) {
            val fx = if (side == 0) 34f else 53f
            val dy = if (side == 0) lf else rt
            rf.set(fx, 88f + dy, fx + 13f, 97f + dy)
            fill.color = limb
            c.drawOval(rf, fill)
            c.drawOval(rf, ln)
            fill.color = padCol
            c.drawCircle(fx + 6.5f, 93.8f + dy, 2.2f, fill)
        }
        // tay
        val arm = if (walking) sin(ph) * 5f else if (mood == Mood.HAPPY) sin(now * 0.01f) * 4f else 0f
        rf.set(24f, 67f + arm, 35f, 81f + arm)
        fill.color = armCol
        c.drawOval(rf, fill)
        c.drawOval(rf, ln)
        rf.set(65f, 67f - arm, 76f, 81f - arm)
        c.drawOval(rf, fill)
        c.drawOval(rf, ln)

        // bóng dưới cằm
        fill.color = Color.argb(45, 60, 30, 20)
        rf.set(34f, 58f, 66f, 69f)
        c.drawOval(rf, fill)

        // đầu
        shade.shader = headShader
        rf.set(21f, 12f, 79f, 66f)
        c.drawOval(rf, shade)
        shade.shader = null
        c.drawOval(rf, ln)
        fill.color = Color.argb(95, 255, 255, 255)
        rf.set(31f, 16f, 47f, 26f)
        c.drawOval(rf, fill)

        // họa tiết: mắt gấu trúc, mõm sáng
        if (panda) {
            fill.color = darkPanda
            c.save(); c.rotate(-18f, 36f, 44f); rf.set(28f, 35f, 45f, 53f); c.drawOval(rf, fill); c.restore()
            c.save(); c.rotate(18f, 64f, 44f); rf.set(55f, 35f, 72f, 53f); c.drawOval(rf, fill); c.restore()
        }
        drawMarkings(c)

        // má hồng
        fill.color = Color.argb(95, 255, 130, 150)
        c.drawCircle(27f, 53f, 5.2f, fill)
        c.drawCircle(73f, 53f, 5.2f, fill)
        fill.color = Color.argb(70, 255, 160, 175)
        c.drawCircle(27f, 53f, 3.2f, fill)
        c.drawCircle(73f, 53f, 3.2f, fill)

        // mắt
        val blink = (now % 3600L) < 140L
        aEye(c, 38f, 43f, blink)
        aEye(c, 62f, 43f, blink)
        if (mood == Mood.SAD) {
            c.drawLine(32f, 33f, 43f, 36f, ln)
            c.drawLine(68f, 33f, 57f, 36f, ln)
            fill.color = Color.parseColor("#6EC6FF")
            c.drawCircle(35f, 52f, 2f, fill)
        }

        // mũi, miệng
        if (species == "rooster") {
            drawBeak(c, now)
        } else {
            if (species != "ox" && species != "pig" && species != "horse") drawNose(c)
            c.save()
            c.translate(0f, if (species == "ox" || species == "pig") 4f else if (species == "horse") 3f else 0f)
            aMouth(c, now)
            c.restore()
        }

        // ria mèo
        if (species == "cat") {
            ln.color = Color.argb(150, Color.red(cOutline), Color.green(cOutline), Color.blue(cOutline))
            ln.strokeWidth = 0.9f
            c.drawLine(24f, 49f, 13f, 46.5f, ln); c.drawLine(24f, 53f, 13f, 54f, ln)
            c.drawLine(76f, 49f, 87f, 46.5f, ln); c.drawLine(76f, 53f, 87f, 54f, ln)
            ln.color = cOutline
            ln.strokeWidth = 1.4f
        }
        c.restore()
    }

    // ================= THÊM: chuột, trâu, hổ, ngựa, dê/cừu, khỉ, heo, gà, rắn =================

    private fun maneColor(): Int {
        val lum = (Color.red(cBody) * 299 + Color.green(cBody) * 587 + Color.blue(cBody) * 114) / 1000
        return if (lum > 225) Color.parseColor("#FFB6C9") else lerp(cBody, Color.parseColor("#2E1B12"), 0.72f)
    }

    private fun drawNose(c: Canvas) {
        path.reset()
        path.moveTo(46.8f, 48.5f)
        path.quadTo(50f, 47f, 53.2f, 48.5f)
        path.quadTo(52f, 52f, 50f, 52.3f)
        path.quadTo(48f, 52f, 46.8f, 48.5f)
        path.close()
        val pinkNose = species == "cat" || species == "bunny" || species == "mouse" ||
            species == "tiger" || species == "goat"
        fill.color = if (pinkNose) Color.parseColor("#FF9AA8") else Color.parseColor("#3F2E2A")
        c.drawPath(path, fill)
        fill.color = Color.argb(180, 255, 255, 255)
        c.drawCircle(49f, 48.9f, 0.7f, fill)
    }

    /** Mỏ, yếm của gà. */
    private fun drawBeak(c: Canvas, now: Long) {
        val eating = actTime(now) >= 0L && act == Act.EAT
        val open = eating || mood == Mood.HUNGRY || mood == Mood.HAPPY
        val o = if (eating) 2f + (sin(now * 0.03f) + 1f) * 2f else if (open) 3f else 0f
        rf.set(46.5f, 55f + o, 53.5f, 65f + o)
        fill.color = Color.parseColor("#E5484D")
        c.drawOval(rf, fill)
        c.drawOval(rf, ln)
        if (open) {
            path.reset()
            path.moveTo(46f, 55f + o); path.lineTo(54f, 55f + o); path.lineTo(50f, 59f + o); path.close()
            fill.color = Color.parseColor("#F29A1A")
            c.drawPath(path, fill)
            c.drawPath(path, ln)
        }
        path.reset()
        path.moveTo(43.5f, 47f); path.lineTo(56.5f, 47f); path.lineTo(50f, 55f); path.close()
        fill.color = Color.parseColor("#FFB02E")
        c.drawPath(path, fill)
        c.drawPath(path, ln)
    }

    /** Họa tiết riêng của từng loài trên mặt: mõm, sọc, mặt nạ, râu... */
    private fun drawMarkings(c: Canvas) {
        val dk = Color.parseColor("#5B3A2B")
        when (species) {
            "fox", "dog", "bear" -> {
                fill.color = cBelly
                if (species == "fox") rf.set(36f, 46f, 64f, 64f) else rf.set(38f, 47f, 62f, 63f)
                c.drawOval(rf, fill)
            }
            "mouse" -> {
                fill.color = cBelly
                rf.set(40f, 48f, 60f, 63f)
                c.drawOval(rf, fill)
            }
            "tiger" -> {
                fill.color = cBelly
                rf.set(38f, 47f, 62f, 63f)
                c.drawOval(rf, fill)
                ln.color = dk
                ln.strokeWidth = 2.2f
                c.drawLine(50f, 15f, 50f, 25f, ln)
                c.drawLine(43f, 16f, 45f, 24f, ln)
                c.drawLine(57f, 16f, 55f, 24f, ln)
                c.drawLine(22f, 42f, 30f, 44f, ln)
                c.drawLine(22f, 48f, 30f, 48f, ln)
                c.drawLine(78f, 42f, 70f, 44f, ln)
                c.drawLine(78f, 48f, 70f, 48f, ln)
                ln.color = cOutline
                ln.strokeWidth = 1.4f
            }
            "ox" -> {
                if (cow) {
                    fill.color = Color.parseColor("#3A3A44")
                    rf.set(56f, 17f, 72f, 34f)
                    c.drawOval(rf, fill)
                }
                fill.color = Color.parseColor("#FFCFC6")
                rf.set(34f, 46f, 66f, 66f)
                c.drawOval(rf, fill)
                c.drawOval(rf, ln)
                fill.color = Color.parseColor("#C9776B")
                rf.set(41f, 52f, 46f, 57f); c.drawOval(rf, fill)
                rf.set(54f, 52f, 59f, 57f); c.drawOval(rf, fill)
            }
            "horse" -> {
                fill.color = cBelly
                rf.set(35f, 45f, 65f, 67f)
                c.drawOval(rf, fill)
                c.drawOval(rf, ln)
                fill.color = Color.parseColor("#4B3A36")
                rf.set(43f, 49.5f, 46.5f, 53f); c.drawOval(rf, fill)
                rf.set(53.5f, 49.5f, 57f, 53f); c.drawOval(rf, fill)
                path.reset()
                path.moveTo(44f, 12f)
                path.quadTo(56f, 8f, 62f, 18f)
                path.quadTo(54f, 22f, 52f, 34f)
                path.quadTo(46f, 24f, 44f, 12f)
                path.close()
                fill.color = maneColor()
                c.drawPath(path, fill)
                c.drawPath(path, ln)
            }
            "goat" -> {
                if (sheep) {
                    fill.color = Color.parseColor("#5A5663")
                    rf.set(29f, 28f, 71f, 66f)
                    c.drawOval(rf, fill)
                    c.drawOval(rf, ln)
                } else {
                    fill.color = cBelly
                    rf.set(38f, 47f, 62f, 63f)
                    c.drawOval(rf, fill)
                    path.reset()
                    path.moveTo(45f, 62f); path.lineTo(55f, 62f); path.lineTo(50f, 73f); path.close()
                    c.drawPath(path, fill)
                    c.drawPath(path, ln)
                }
            }
            "monkey" -> {
                fill.color = cBelly
                rf.set(30f, 34f, 70f, 66f)
                c.drawOval(rf, fill)
                fill.color = Color.parseColor("#7A5238")
                c.drawCircle(48.2f, 50f, 0.8f, fill)
                c.drawCircle(51.8f, 50f, 0.8f, fill)
            }
            "pig" -> {
                fill.color = Color.parseColor("#FF9CB4")
                rf.set(40f, 46f, 60f, 58f)
                c.drawOval(rf, fill)
                c.drawOval(rf, ln)
                fill.color = Color.parseColor("#C95F7C")
                rf.set(45f, 50f, 48.4f, 54.5f); c.drawOval(rf, fill)
                rf.set(51.6f, 50f, 55f, 54.5f); c.drawOval(rf, fill)
            }
        }
    }

    /** Rắn chibi: thân cuộn tròn uốn lượn, đầu to, lưỡi chẻ thè ra thụt vào. */
    private fun drawSnake(c: Canvas, now: Long, lift: Float) {
        val sleeping = mood == Mood.SLEEP
        c.save()
        c.translate(50f, 0f)
        c.scale(faceScale, 1f)
        c.translate(-50f, lift)
        ln.color = cOutline
        ln.strokeWidth = 1.4f
        val speed = if (walking) 0.012f else if (sleeping) 0.0015f else 0.005f
        val amp = if (sleeping) 0.6f else if (walking) 3f else 1.8f
        val ph = now * speed
        val n = 18
        for (pass in 0..1) {
            for (i in n downTo 0) {
                val t = i / n.toFloat()
                val w = sin(ph * 3f - t * 6f) * amp * (0.2f + t)
                val x = bez(t, 50f, 92f, 6f, 82f) + w * 0.5f
                val y = bez(t, 62f, 70f, 100f, 90f) + w * 0.6f
                val r = 11f - 8f * t
                if (pass == 0) {
                    fill.color = cOutline
                    c.drawCircle(x, y, r + 1.3f, fill)
                } else {
                    fill.color = cBody
                    c.drawCircle(x, y, r, fill)
                    fill.color = Color.argb(110, 255, 255, 255)
                    c.drawCircle(x - r * 0.25f, y - r * 0.35f, r * 0.35f, fill)
                    if (i % 3 == 1) {
                        fill.color = cDark
                        c.drawCircle(x, y + r * 0.1f, r * 0.38f, fill)
                    }
                }
            }
        }

        // đầu
        shade.shader = headShader
        rf.set(23f, 12f, 77f, 64f)
        c.drawOval(rf, shade)
        shade.shader = null
        c.drawOval(rf, ln)
        fill.color = Color.argb(95, 255, 255, 255)
        rf.set(31f, 16f, 47f, 26f)
        c.drawOval(rf, fill)
        // họa tiết hình thoi trên trán
        fill.color = cDark
        c.drawCircle(50f, 20f, 2.4f, fill)
        c.drawCircle(44f, 25f, 1.8f, fill)
        c.drawCircle(56f, 25f, 1.8f, fill)

        fill.color = Color.argb(95, 255, 130, 150)
        c.drawCircle(27f, 52f, 5.2f, fill)
        c.drawCircle(73f, 52f, 5.2f, fill)
        val blink = (now % 3600L) < 140L
        aEye(c, 38f, 42f, blink)
        aEye(c, 62f, 42f, blink)
        fill.color = Color.parseColor("#3F2E2A")
        c.drawCircle(47.8f, 49.5f, 0.9f, fill)
        c.drawCircle(52.2f, 49.5f, 0.9f, fill)
        // lưỡi chẻ
        if (!sleeping && mood != Mood.SAD) {
            val fl = (sin(now * 0.012f) + 1f) / 2f
            val tipY = 63f + fl * 6f
            ln.color = Color.parseColor("#E5484D")
            ln.strokeWidth = 1.6f
            c.drawLine(50f, 57f, 50f, tipY, ln)
            c.drawLine(50f, tipY, 47.5f, tipY + 3.5f, ln)
            c.drawLine(50f, tipY, 52.5f, tipY + 3.5f, ln)
            ln.color = cOutline
            ln.strokeWidth = 1.4f
        }
        aMouth(c, now)
        c.restore()
    }

    // ================= RỒNG CHIBI =================

    /** Một lọn bờm/râu trắng bay: từ (x,y) cong tới (x+dx, y+dy). */
    private fun tuft(c: Canvas, x: Float, y: Float, dx: Float, dy: Float, w: Float) {
        path.reset()
        path.moveTo(x - w, y)
        path.quadTo(x + dx * 0.4f - w, y + dy * 0.7f, x + dx, y + dy)
        path.quadTo(x + dx * 0.5f + w, y + dy * 0.4f, x + w, y)
        path.close()
        fill.color = Color.argb(240, 255, 255, 255)
        c.drawPath(path, fill)
        ln.strokeWidth = 0.8f
        ln.color = Color.parseColor("#BCD3D6")
        c.drawPath(path, ln)
        ln.strokeWidth = 1.6f
        ln.color = ink
    }

    /** Sừng bạc có nhánh. sign = -1 trái, +1 phải. */
    private fun antler(c: Canvas, sign: Float, sway: Float) {
        val bx = 50f + sign * 10f
        path.reset()
        path.moveTo(bx, 21f)
        path.quadTo(bx + sign * 9f, 12f, bx + sign * 5f + sway, 1.5f)
        path.moveTo(bx + sign * 5.5f, 11f)
        path.quadTo(bx + sign * 11f, 9f, bx + sign * 16f, 7f - sway * 0.3f)
        ln.strokeWidth = 4.2f; ln.color = ink2; c.drawPath(path, ln)
        ln.strokeWidth = 2.5f; ln.color = Color.parseColor("#D6DEE4"); c.drawPath(path, ln)
        ln.strokeWidth = 1.6f; ln.color = ink
    }

    /** Vây trong suốt ánh cầu vồng ở hai bên đầu. */
    private fun finLeaf(c: Canvas, sign: Float, flap: Float) {
        val x0 = 50f + sign * 23f
        path.reset()
        path.moveTo(x0, 37f)
        path.quadTo(50f + sign * 41f, 22f - flap, 50f + sign * 43f, 38f - flap * 0.5f)
        path.quadTo(50f + sign * 36f, 47f, x0, 44f)
        path.close()
        fill.color = Color.argb(150, 200, 245, 240)
        c.drawPath(path, fill)
        fill.color = Color.argb(90, 225, 205, 255)
        c.save()
        c.scale(0.7f, 0.7f, x0, 41f)
        c.drawPath(path, fill)
        c.restore()
        ln.strokeWidth = 0.9f; ln.color = Color.parseColor("#7FC6C0")
        c.drawPath(path, ln)
        ln.strokeWidth = 1.6f; ln.color = ink
    }

    private fun dragonEye(c: Canvas, x: Float, y: Float, blink: Boolean) {
        val glow = lerp(dragonAccent, Color.parseColor("#0A9E8E"), 0.35f)
        ln.color = ink2
        when {
            mood == Mood.SLEEP || blink -> {
                rf.set(x - 5f, y - 3f, x + 5f, y + 5f)
                c.drawArc(rf, 0f, 180f, false, ln)
            }
            mood == Mood.HAPPY -> {
                rf.set(x - 5f, y - 2f, x + 5f, y + 8f)
                c.drawArc(rf, 180f, 180f, false, ln)
            }
            mood == Mood.TIRED -> {
                fill.color = Color.argb(70, Color.red(glow), Color.green(glow), Color.blue(glow))
                c.drawCircle(x, y + 1f, 6f, fill)
                rf.set(x - 4.2f, y - 0.5f, x + 4.2f, y + 3f)
                fill.color = glow
                c.drawOval(rf, fill)
            }
            else -> {
                fill.color = Color.argb(70, Color.red(glow), Color.green(glow), Color.blue(glow))
                c.drawCircle(x, y, 8f, fill)
                rf.set(x - 4.8f, y - 6f, x + 4.8f, y + 6f)
                fill.color = glow
                c.drawOval(rf, fill)
                rf.set(x - 2f + gazeCur * 1.6f, y - 4f, x + 2f + gazeCur * 1.6f, y + 4.2f)
                fill.color = Color.parseColor("#16323A")
                c.drawOval(rf, fill)
                fill.color = Color.WHITE
                c.drawCircle(x + 1.7f, y - 2.6f, 1.6f, fill)
                c.drawCircle(x - 1.6f, y + 2.4f, 0.8f, fill)
            }
        }
        ln.color = ink
    }

    private fun dragonMouth(c: Canvas, now: Long, at: Long) {
        val eating = at >= 0L && act == Act.EAT
        val open = when {
            eating -> 3f + (sin(now * 0.03f) + 1f) * 4f
            mood == Mood.HAPPY -> 8f
            mood == Mood.HUNGRY -> 9f
            else -> 0f
        }
        ln.color = ink2
        if (open > 0f) {
            rf.set(43f, 50f, 57f, 50f + open)
            fill.color = Color.parseColor("#7A3B4A")
            c.drawOval(rf, fill)
            // răng nanh
            fill.color = Color.WHITE
            path.reset()
            path.moveTo(44.5f, 51f); path.lineTo(46.5f, 51f); path.lineTo(45.5f, 54.5f); path.close()
            path.moveTo(53.5f, 51f); path.lineTo(55.5f, 51f); path.lineTo(54.5f, 54.5f); path.close()
            c.drawPath(path, fill)
        } else if (mood == Mood.SAD) {
            rf.set(44f, 54f, 56f, 61f)
            c.drawArc(rf, 180f, 180f, false, ln)
        } else {
            rf.set(44f, 50f, 56f, 57f)
            c.drawArc(rf, 0f, 180f, false, ln)
        }
        ln.color = ink
    }

    private fun drawDragon(c: Canvas, now: Long, lift: Float, at: Long) {
        val sleeping = mood == Mood.SLEEP
        val speed = if (walking) 0.012f else if (sleeping) 0.0015f else 0.005f
        val amp = if (sleeping) 0.8f else if (walking) 3.4f else 2.2f
        val ph = now * speed

        c.save()
        c.translate(50f, 0f)
        c.scale(faceScale, 1f)
        c.translate(-50f, lift)

        // hào quang và những đốm sáng lấp lánh quanh rồng
        shade.shader = auraShader
        c.drawCircle(50f, 50f, 50f, shade)
        shade.shader = null
        for (i in 0..5) {
            val a = (sin(now * 0.004f + i * 1.9f) + 1f) / 2f
            fill.color = Color.argb((a * 210).toInt(), 255, 255, 255)
            c.drawCircle(12f + i * 15f + sin(now * 0.001f + i) * 3f, 14f + ((i * 37) % 60), 0.9f + a * 1.1f, fill)
        }

        // thân uốn lượn: các đốt tròn nối từ đuôi lên cổ, vòng viền tạo thành vảy
        val n = 16
        ln.strokeWidth = 1.1f
        ln.color = ink2
        for (i in n downTo 0) {
            val t = i / n.toFloat()
            val w = sin(ph * 3f - t * 7f) * amp * (0.3f + t)
            val x = bez(t, 50f, 86f, 36f, 12f) + w * 0.6f
            val y = bez(t, 60f, 64f, 104f, 70f) + w
            val r = 9.5f - 6f * t
            fill.color = lerp(dragonBody, dragonAccent, t * 0.8f)
            c.drawCircle(x, y, r, fill)
            c.drawCircle(x, y, r, ln)
            fill.color = Color.argb(110, 140, 240, 225)
            c.drawCircle(x - r * 0.25f, y - r * 0.3f, r * 0.32f, fill)
            // vây lưng
            if (i in 3..13 && i % 2 == 1) {
                tuft(c, x, y - r * 0.9f, -2f + sin(ph * 2f + i) * 2f, -7f, 2.2f)
            }
        }
        // chùm lông đuôi
        run {
            val tx = bez(1f, 50f, 86f, 36f, 12f)
            val ty = bez(1f, 60f, 64f, 104f, 70f)
            val sw = sin(ph * 3f) * 3f
            tuft(c, tx, ty, -9f + sw, -7f, 2.6f)
            tuft(c, tx, ty, -10f + sw, 1f, 2.6f)
            tuft(c, tx, ty, -6f + sw, 8f, 2.4f)
        }

        // móng vuốt phía trước
        val step = if (walking) sin(now * 0.02f) * 2.5f else 0f
        for (side in 0..1) {
            val px = if (side == 0) 38f else 62f
            val py = 73f + (if (side == 0) step else -step)
            rf.set(px - 5f, py - 3.5f, px + 5f, py + 4f)
            fill.color = dragonBody
            c.drawOval(rf, fill)
            ln.strokeWidth = 1.1f; ln.color = ink2
            c.drawOval(rf, ln)
            ln.strokeWidth = 1.3f; ln.color = Color.parseColor("#9AA9B0")
            for (k in -1..1) c.drawLine(px + k * 2.6f, py + 3.5f, px + k * 3.4f, py + 7f, ln)
            ln.strokeWidth = 1.6f; ln.color = ink
        }

        // bờm trắng bay sau đầu, râu cằm
        val sway = sin(ph * 2f)
        tuft(c, 28f, 22f, -16f + sway * 3f, -5f, 3f)
        tuft(c, 24f, 32f, -21f + sway * 3f, 3f, 3.2f)
        tuft(c, 26f, 44f, -18f + sway * 3f, 14f, 3f)
        tuft(c, 72f, 22f, 16f - sway * 3f, -5f, 3f)
        tuft(c, 76f, 32f, 21f - sway * 3f, 3f, 3.2f)
        tuft(c, 74f, 44f, 18f - sway * 3f, 14f, 3f)
        tuft(c, 46f, 17f, -5f + sway * 2f, -9f, 2.5f)
        tuft(c, 54f, 17f, 5f - sway * 2f, -9f, 2.5f)

        // vây ánh cầu vồng bên đầu
        val flap = sin(now * (if (walking) 0.02f else 0.006f)) * 3f
        finLeaf(c, -1f, flap)
        finLeaf(c, 1f, flap)

        // sừng
        antler(c, -1f, sway * 1.2f)
        antler(c, 1f, -sway * 1.2f)

        // đầu
        ln.strokeWidth = 1.2f; ln.color = ink2
        rf.set(26f, 15f, 74f, 58f)
        shade.shader = dragonHeadShader
        c.drawOval(rf, shade)
        shade.shader = null
        c.drawOval(rf, ln)
        // mõm
        rf.set(37f, 41f, 63f, 58f)
        fill.color = Color.WHITE
        c.drawOval(rf, fill)
        c.drawOval(rf, ln)
        fill.color = ink2
        c.drawCircle(46f, 47f, 0.9f, fill)
        c.drawCircle(54f, 47f, 0.9f, fill)
        ln.strokeWidth = 1.6f; ln.color = ink

        // má hồng, mắt
        fill.color = Color.argb(110, 255, 170, 185)
        c.drawCircle(31f, 46f, 4.2f, fill)
        c.drawCircle(69f, 46f, 4.2f, fill)
        val blink = (now % 4000L) < 150L
        dragonEye(c, 39f, 35f, blink)
        dragonEye(c, 61f, 35f, blink)
        if (mood == Mood.SAD) {
            ln.color = ink2
            c.drawLine(33f, 26f, 43f, 29f, ln)
            c.drawLine(67f, 26f, 57f, 29f, ln)
            ln.color = ink
            fill.color = Color.parseColor("#6EC6FF")
            c.drawCircle(36f, 44f, 1.8f, fill)
        }
        dragonMouth(c, now, at)

        // hai sợi râu dài bay lượn
        for (sign in intArrayOf(-1, 1)) {
            val sx = 50f + sign * 7f
            val wv = sin(ph * 2f + sign) * 6f
            path.reset()
            path.moveTo(sx, 50f)
            path.quadTo(50f + sign * 27f, 51f + wv, 50f + sign * 44f, 41f + wv * 1.4f)
            ln.strokeWidth = 2.2f; ln.color = ink2; c.drawPath(path, ln)
            ln.strokeWidth = 1.1f; ln.color = Color.parseColor("#F4FAFB"); c.drawPath(path, ln)
        }
        ln.strokeWidth = 1.6f; ln.color = ink

        // viên ngọc rồng phát sáng, nhịp thở
        if (!sleeping) {
            val pr = 4.2f + sin(now * 0.006f) * 0.8f
            val gx = 86f
            val gy = 66f + sin(now * 0.004f) * 2f
            fill.color = Color.argb(50, 160, 245, 255)
            c.drawCircle(gx, gy, pr + 4.5f, fill)
            fill.color = Color.argb(90, 190, 250, 255)
            c.drawCircle(gx, gy, pr + 2.2f, fill)
            fill.color = Color.parseColor("#EFFFFF")
            c.drawCircle(gx, gy, pr, fill)
            fill.color = Color.WHITE
            c.drawCircle(gx - 1.2f, gy - 1.3f, 1.3f, fill)
        }
        c.restore()
    }
}
