package com.example.thuao

import android.content.Context

/** Danh sách các bé thú đang nuôi. */
object PetStore {
    private fun meta(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("pets_meta", Context.MODE_PRIVATE)

    fun ids(ctx: Context): List<String> =
        (meta(ctx).getString("ids", "") ?: "").split(",").filter { it.isNotBlank() }

    private fun saveIds(ctx: Context, l: List<String>) {
        meta(ctx).edit().putString("ids", l.joinToString(",")).apply()
    }

    fun ensureDefault(ctx: Context) {
        if (ids(ctx).isEmpty()) add(ctx, "Mochi", "cat:0")
    }

    fun add(ctx: Context, name: String, look: String, id: String = "p" + System.currentTimeMillis()): String {
        val s = PetState(ctx, id)
        s.name = name
        s.look = look
        s.save()
        saveIds(ctx, ids(ctx) + id)
        return id
    }

    fun remove(ctx: Context, id: String) {
        val app = ctx.applicationContext
        val look = app.getSharedPreferences("pet_$id", Context.MODE_PRIVATE).getString("look", "cat:0") ?: "cat:0"
        if (look.startsWith("img:")) Looks.drop(look.removePrefix("img:"))
        app.deleteSharedPreferences("pet_$id")
        saveIds(ctx, ids(ctx).filter { it != id })
    }

    fun selected(ctx: Context): String {
        val l = ids(ctx)
        val s = meta(ctx).getString("sel", null)
        return if (s != null && s in l) s else l.first()
    }

    fun select(ctx: Context, id: String) {
        meta(ctx).edit().putString("sel", id).apply()
    }

    fun isOverlayOn(ctx: Context) = meta(ctx).getBoolean("overlay_on", false)

    fun setOverlayOn(ctx: Context, on: Boolean) {
        meta(ctx).edit().putBoolean("overlay_on", on).apply()
    }
}
