package com.example.thuao

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Một bé đang chạy trên màn hình: cửa sổ nổi riêng + vị trí, vận tốc, hành vi. */
private class Walker(
    val id: String,
    val view: PetView,
    val lp: WindowManager.LayoutParams,
    val flying: Boolean
) {
    var targetY = 0f
    var nextPick = 0L
    var px = 0f
    var py = 0f
    var vx = 0f
    var vy = 0f
    var dir = 1
    var mode = 0              // 0 = đứng nghỉ, 1 = đi bộ
    var modeUntil = 0L
    var pausedUntil = 0L      // đứng yên (đang mở menu / đang làm hoạt hình)
    var dragging = false
    var lastMoodCheck = 0L
    var mood = Mood.NORMAL
    // đo vận tốc ngón tay để ném
    var fvx = 0f
    var fvy = 0f
    var lastRawX = 0f
    var lastRawY = 0f
    var lastT = 0L
}

/**
 * Thả các bé ra màn hình: chạy/bay mượt theo nhịp màn hình, nhảy có đà, bóp người khi tiếp đất,
 * chạm vào bé để hiện menu nhanh (ăn, chơi, tắm, ngủ), kéo rồi buông tay để ném.
 */
class PetOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "stop"
        private const val MAX_PETS = 8
    }

    private lateinit var wm: WindowManager
    private val walkers = ArrayList<Walker>()

    private var sw = 0
    private var sh = 0
    private var size = 0
    private var groundY = 0f
    private var lastSync = 0L
    private var started = false

    private var running = false
    private var lastFrame = 0L
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            val dt = if (lastFrame == 0L) 0.016f
            else ((frameTimeNanos - lastFrame) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            lastFrame = frameTimeNanos
            step(dt)
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private var menuView: View? = null
    private var menuFor = ""
    private var menuUntil = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> stopLoop()      // tắt màn hình thì ngừng cho đỡ tốn pin
                Intent.ACTION_SCREEN_ON -> startLoop()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY
        started = true
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        measureScreen()
        syncPets()
        PetStore.setOverlayOn(this, true)
        registerReceiver(
            screenReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
        )
        startLoop()
        return START_NOT_STICKY
    }

    private fun startLoop() {
        if (running) return
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    private fun stopLoop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("pet", "Thú ảo", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, PetOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Thu thú về", stop
        ).build()
        val n = Notification.Builder(this, "pet")
            .setContentTitle("Thú ảo đang chạy trên màn hình")
            .setSmallIcon(android.R.drawable.ic_menu_myplaces)
            .addAction(action)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun measureScreen() {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels
        sh = m.heightPixels
        val d = resources.displayMetrics.density
        size = (110 * d).toInt()
        groundY = sh - size - 90 * d
    }

    /** Đồng bộ danh sách bé trên màn hình với danh sách trong app (thêm/xóa bé khi đang thả). */
    private fun syncPets() {
        val ids = PetStore.ids(this).take(MAX_PETS)
        val iter = walkers.iterator()
        while (iter.hasNext()) {
            val w = iter.next()
            if (w.id !in ids) {
                if (menuFor == w.id) hideMenu()
                runCatching { wm.removeView(w.view) }
                iter.remove()
            }
        }
        for (id in ids) {
            if (walkers.none { it.id == id }) addWalker(id)
        }
    }

    private fun addWalker(id: String) {
        val st = PetState(this, id)
        val v = PetView(this)
        v.setLook(this, st.look)
        v.setStyle(st.motion, st.faceLeft)
        v.mood = st.mood()
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        val w = Walker(id, v, params, st.look.startsWith("dragon:") || st.motion == "fly")
        w.px = Random.nextInt(maxOf(1, sw - size)).toFloat()
        w.py = if (w.flying) sh * 0.3f + Random.nextFloat() * (groundY - sh * 0.3f) else groundY
        w.targetY = w.py
        w.dir = if (Random.nextBoolean()) 1 else -1
        w.mood = v.mood
        params.x = w.px.toInt()
        params.y = w.py.toInt()

        val d = resources.displayMetrics.density
        val slop = 8 * d
        val maxFling = 1800f * d
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = w.px; startY = w.py
                    moved = false
                    w.dragging = true
                    w.vx = 0f; w.vy = 0f
                    w.fvx = 0f; w.fvy = 0f
                    w.lastRawX = e.rawX; w.lastRawY = e.rawY; w.lastT = e.eventTime
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        w.px = (startX + dx).coerceIn(0f, (sw - size).toFloat())
                        w.py = (startY + dy).coerceIn(0f, (sh - size).toFloat())
                        applyPos(w)
                        val dtm = (e.eventTime - w.lastT) / 1000f
                        if (dtm > 0.001f) {
                            w.fvx = w.fvx * 0.6f + 0.4f * (e.rawX - w.lastRawX) / dtm
                            w.fvy = w.fvy * 0.6f + 0.4f * (e.rawY - w.lastRawY) / dtm
                        }
                        w.lastRawX = e.rawX; w.lastRawY = e.rawY; w.lastT = e.eventTime
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    w.dragging = false
                    if (moved) {
                        // buông tay khi ngón còn đang lướt thì ném theo hướng đó
                        if (e.eventTime - w.lastT < 90L) {
                            w.vx = w.fvx.coerceIn(-maxFling, maxFling)
                            w.vy = w.fvy.coerceIn(-maxFling, maxFling)
                        }
                        hideMenu()
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        onTap(w)
                    }
                }
            }
            true
        }
        wm.addView(v, params)
        walkers.add(w)
    }

    // ---------- chạm vào bé: nhả tim + bật/tắt menu nhanh ----------
    private fun onTap(w: Walker) {
        w.view.hearts()
        val s = PetState(this, w.id)
        s.cuddle()
        s.save()
        w.lastMoodCheck = 0L
        if (menuView != null && menuFor == w.id) hideMenu() else showMenu(w)
    }

    private fun showMenu(w: Walker) {
        hideMenu()
        val d = resources.displayMetrics.density
        val sleeping = PetState(this, w.id).sleeping
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 30 * d
                setColor(Color.argb(215, 30, 30, 40))
            }
        }
        val labels = listOf("🍖", "🎾", "🛁", if (sleeping) "☀️" else "😴")
        labels.forEachIndexed { i, t ->
            row.addView(
                TextView(this).apply {
                    text = t
                    textSize = 22f
                    gravity = Gravity.CENTER
                    setOnClickListener { menuAct(w, i) }
                },
                LinearLayout.LayoutParams((44 * d).toInt(), (44 * d).toInt())
            )
        }
        val spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        row.measure(spec, spec)
        val mw = row.measuredWidth
        val mh = row.measuredHeight
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = (w.px + size / 2f - mw / 2f).toInt().coerceIn(0, max(0, sw - mw))
        val above = (w.py - mh).toInt()
        params.y = if (above < 0) (w.py + size * 0.8f).toInt() else above
        wm.addView(row, params)
        menuView = row
        menuFor = w.id
        val now = SystemClock.uptimeMillis()
        menuUntil = now + 4500L
        w.pausedUntil = now + 4500L
    }

    private fun hideMenu() {
        menuView?.let { runCatching { wm.removeView(it) } }
        menuView = null
        val id = menuFor
        menuFor = ""
        walkers.firstOrNull { it.id == id }?.pausedUntil = SystemClock.uptimeMillis() + 300L
    }

    private fun menuAct(w: Walker, which: Int) {
        val s = PetState(this, w.id)
        val wasSleeping = s.sleeping
        val msg = when (which) {
            0 -> s.feed()
            1 -> s.play()
            2 -> s.bath()
            else -> s.toggleSleep()
        }
        s.save()
        if (!wasSleeping) {
            when (which) {
                0 -> w.view.doAct(Act.EAT)
                1 -> w.view.doAct(Act.PLAY)
                2 -> w.view.doAct(Act.BATH)
            }
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        w.lastMoodCheck = 0L
        hideMenu()
        w.pausedUntil = SystemClock.uptimeMillis() + 2800L
    }

    // ---------- chuyển động ----------
    private fun applyPos(w: Walker) {
        val nx = w.px.toInt()
        val ny = w.py.toInt()
        if (nx == w.lp.x && ny == w.lp.y) return
        w.lp.x = nx
        w.lp.y = ny
        try { wm.updateViewLayout(w.view, w.lp) } catch (e: Exception) { }
    }

    private fun jump(w: Walker) {
        if (w.py >= groundY - 1f) {
            w.vy = -420f * resources.displayMetrics.density
            w.view.jumped()
        }
    }

    private fun step(dt: Float) {
        val now = SystemClock.uptimeMillis()
        if (now - lastSync > 4000L) {
            syncPets()
            lastSync = now
        }
        if (menuView != null && now > menuUntil) hideMenu()
        val d = resources.displayMetrics.density
        for (w in walkers) stepOne(w, now, d, dt)
    }

    /** Rồng bay lượn ở nhiều độ cao; bị ném thì bay quán tính rồi giảm tốc; ngủ thì hạ xuống nằm trên mây. */
    private fun stepFly(w: Walker, now: Long, d: Float, dt: Float) {
        val v = w.view
        if (abs(w.vx) > 20f * d || abs(w.vy) > 20f * d) {
            w.px += w.vx * dt
            w.py += w.vy * dt
            if (w.px < 0f) { w.px = 0f; w.vx = abs(w.vx) * 0.7f }
            if (w.px > sw - size) { w.px = (sw - size).toFloat(); w.vx = -abs(w.vx) * 0.7f }
            if (w.py < 0f) { w.py = 0f; w.vy = abs(w.vy) * 0.7f }
            if (w.py > groundY) { w.py = groundY; w.vy = -abs(w.vy) * 0.5f }
            val damp = (1f - 2.2f * dt).coerceAtLeast(0f)
            w.vx *= damp
            w.vy *= damp
            w.targetY = w.py
            v.facing = if (w.vx >= 0f) 1 else -1
            v.walking = true
            applyPos(w)
            return
        }
        w.vx = 0f
        w.vy = 0f
        if (w.mood == Mood.SLEEP) {
            if (w.py < groundY - 1f) {
                w.py = min(groundY, w.py + (groundY - w.py) * min(1f, 3.5f * dt) + 40f * d * dt)
                applyPos(w)
            }
            v.walking = false
            return
        }
        if (now < w.pausedUntil) {
            v.walking = false
            applyPos(w)
            return
        }
        if (now > w.nextPick) {
            val top = sh * 0.22f
            w.targetY = top + Random.nextFloat() * (groundY - top)
            w.nextPick = now + Random.nextLong(2500L, 6000L)
            if (Random.nextInt(100) < 25) w.dir = -w.dir
        }
        val slow = w.mood == Mood.HUNGRY || w.mood == Mood.TIRED || w.mood == Mood.SAD
        var speed = (if (slow) 50f else 95f) * d
        if (w.mood == Mood.HAPPY) speed *= 1.3f
        w.px += w.dir * speed * dt
        if (w.px <= 0f) { w.px = 0f; w.dir = 1 }
        if (w.px >= sw - size) { w.px = (sw - size).toFloat(); w.dir = -1 }
        w.py += (w.targetY - w.py) * min(1f, 1.8f * dt)
        v.facing = w.dir
        v.walking = true
        applyPos(w)
    }

    private fun stepOne(w: Walker, now: Long, d: Float, dt: Float) {
        val v = w.view
        if (now - w.lastMoodCheck > 3000L) {
            w.mood = PetState(this, w.id).mood()
            v.mood = w.mood
            w.lastMoodCheck = now
        }
        if (w.dragging) {
            v.walking = false
            return
        }
        if (w.flying) {
            stepFly(w, now, d, dt)
            return
        }

        // vật lý theo thời gian thực: rơi, nảy, trượt
        val g = 1400f * d
        val onGround = w.py >= groundY - 0.5f && w.vy >= 0f
        if (!onGround) {
            w.vy += g * dt
            w.py += w.vy * dt
            w.px += w.vx * dt
            if (w.px < 0f) { w.px = 0f; w.vx = -w.vx * 0.6f }
            if (w.px > sw - size) { w.px = (sw - size).toFloat(); w.vx = -w.vx * 0.6f }
            if (w.py < 0f) { w.py = 0f; w.vy = abs(w.vy) * 0.5f }
            if (w.py >= groundY) {
                val impact = w.vy
                w.py = groundY
                w.vx *= 0.6f
                if (impact > 450f * d) {
                    w.vy = -impact * 0.3f
                    v.landed(0.2f)
                } else {
                    w.vy = 0f
                    v.landed(min(0.18f, impact / (3500f * d)))
                }
            }
            v.walking = false
            applyPos(w)
            return
        }
        if (abs(w.vx) > 8f) {
            w.px += w.vx * dt
            w.vx *= (1f - 5f * dt).coerceAtLeast(0f)
            if (w.px < 0f) { w.px = 0f; w.vx = 0f }
            if (w.px > sw - size) { w.px = (sw - size).toFloat(); w.vx = 0f }
            v.walking = false
            applyPos(w)
            return
        }
        w.vx = 0f
        if (w.py > groundY) w.py = groundY
        if (w.mood == Mood.SLEEP || now < w.pausedUntil) {
            v.walking = false
            applyPos(w)
            return
        }

        if (now > w.modeUntil) {
            if (w.mode == 0 && Random.nextInt(100) < 80) {
                w.mode = 1
                w.dir = if (Random.nextBoolean()) 1 else -1
                w.modeUntil = now + Random.nextLong(2000L, 5000L)
            } else {
                w.mode = 0
                w.modeUntil = now + Random.nextLong(1000L, 3000L)
                if (Random.nextInt(100) < 35) jump(w)
            }
        }

        if (w.mode == 1) {
            val slow = w.mood == Mood.HUNGRY || w.mood == Mood.TIRED || w.mood == Mood.SAD
            var speed = (if (slow) 40f else 68f) * d
            if (w.mood == Mood.HAPPY) speed *= 1.4f
            w.px += w.dir * speed * dt
            if (w.px <= 0f) { w.px = 0f; w.dir = 1 }
            if (w.px >= sw - size) { w.px = (sw - size).toFloat(); w.dir = -1 }
            v.facing = w.dir
            v.walking = true
            if (Random.nextFloat() < 0.25f * dt) jump(w)
        } else {
            v.walking = false
        }
        applyPos(w)
    }

    override fun onDestroy() {
        stopLoop()
        runCatching { unregisterReceiver(screenReceiver) }
        hideMenu()
        for (w in walkers) runCatching { wm.removeView(w.view) }
        walkers.clear()
        PetStore.setOverlayOn(this, false)
        super.onDestroy()
    }
}
